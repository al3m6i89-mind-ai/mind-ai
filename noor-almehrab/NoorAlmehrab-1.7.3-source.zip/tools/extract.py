import re,sys,os,json
root=sys.argv[1]
files=[l.strip() for l in open(sys.argv[2])]
pat=re.compile(r'^\s*const-string(?:/jumbo)? ([vp]\d+), "(.*)"\s*$')
def dec(s):
    return s.encode('latin-1','backslashreplace').decode('unicode_escape').encode('utf-16','surrogatepass').decode('utf-16')
out={}
for f in files:
    for i,l in enumerate(open(os.path.join(root,f),encoding='utf-8')):
        m=pat.match(l)
        if m and re.search(r'\\u06[0-9a-f]{2}|\\u08|\\ufd|\\ufe',m.group(2)):
            s=dec(m.group(2))
            out.setdefault(s,[]).append(f"{f}:{i+1}")
json.dump(out,open(sys.argv[3],'w'),ensure_ascii=False,indent=1)
print(len(out))
