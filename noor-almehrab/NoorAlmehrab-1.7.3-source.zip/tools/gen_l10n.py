import json,sys
sys.path.insert(0, sys.argv[1]); from tr import T
keys=list(json.load(open(sys.argv[2])))
def jesc(s):
    out=[]
    for ch in s:
        o=ord(ch)
        if ch=='\\': out.append('\\\\')
        elif ch=='"': out.append('\\"')
        elif ch=='\n': out.append('\\n')
        elif 32<=o<127: out.append(ch)
        else:
            for u in ch.encode('utf-16-be').hex().upper():
                pass
            b=ch.encode('utf-16-be')
            for i in range(0,len(b),2): out.append('\\u%02X%02X'%(b[i],b[i+1]))
    return ''.join(out)
puts=[]
for i,k in enumerate(keys):
    v=T[i]
    if v.startswith('D:'): v=k+'\n\n'+v[2:]
    puts.append('        m.put("%s", "%s");'%(jesc(k),jesc(v)))
# split into chunks to keep methods small
chunks=[puts[i:i+60] for i in range(0,len(puts),60)]
methods=''.join('    private static void p%d(HashMap<String, String> m) {\n%s\n    }\n\n'%(n,'\n'.join(c)) for n,c in enumerate(chunks))
calls='\n'.join('        p%d(m);'%n for n in range(len(chunks)))
tpl=open(sys.argv[3]).read()
print(tpl.replace('//@CALLS',calls).replace('//@METHODS',methods))
