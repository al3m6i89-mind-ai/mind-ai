import re,sys,os,shutil
mod, files_txt, newsmali = sys.argv[1], sys.argv[2], sys.argv[3]
S = os.path.join(mod,'smali')
L = 'Lcom/nooralmehrab/app/L10n;'
def rd(p): return open(os.path.join(S,p),encoding='utf-8').read()
def wr(p,s): open(os.path.join(S,p),'w',encoding='utf-8').write(s)
def sub1(p, old, new, count=1):
    s=rd(p); n=s.count(old)
    assert n==count, (p, old[:80], n)
    wr(p, s.replace(old,new))

# 1. new classes
for f in os.listdir(newsmali):
    shutil.copy(os.path.join(newsmali,f), os.path.join(S,'com/nooralmehrab/app',f))

# 2. wrap Arabic constants
pat=re.compile(r'^(\s*)const-string(?:/jumbo)? ([vp]\d+), "(.*)"\s*$')
total=0
files=[l.strip()[len('smali/'):] for l in open(files_txt) if l.strip()]
for f in files:
    out=[]
    for line in rd(f).split('\n'):
        out.append(line)
        m=pat.match(line)
        if m and re.search(r'\\u06[0-9a-f]{2}', m.group(3)):
            ind,r=m.group(1),m.group(2)
            out.append('')
            out.append(f'{ind}invoke-static/range {{{r} .. {r}}}, {L}->t(Ljava/lang/String;)Ljava/lang/String;')
            out.append('')
            out.append(f'{ind}move-result-object {r}')
            total+=1
    wr(f,'\n'.join(out))
print('wrapped',total)

# 3/4. layout direction + gravity
for f in ['A0/a.smali','k1.1/b.1.smali','k1.1/c.smali','com/nooralmehrab/app/MainActivity.smali']:
    s=rd(f)
    s,n1=re.subn(r'invoke-virtual \{([vp]\d+), ([vp]\d+)\}, Landroid/view/View;->setLayoutDirection\(I\)V',
                 r'invoke-static {\1, \2}, '+L+r'->dir(Landroid/view/View;I)V', s)
    s,n2=re.subn(r'invoke-virtual \{([vp]\d+), ([vp]\d+)\}, Landroid/widget/TextView;->setGravity\(I\)V',
                 r'invoke-static {\1, \2}, '+L+r'->tg(Landroid/widget/TextView;I)V', s)
    s,n3=re.subn(r'invoke-virtual \{([vp]\d+), ([vp]\d+)\}, Landroid/widget/LinearLayout;->setGravity\(I\)V',
                 r'invoke-static {\1, \2}, '+L+r'->lg(Landroid/widget/LinearLayout;I)V', s)
    wr(f,s); print(f,n1,n2,n3)

# 5. geocoder language
sub1('k1.1/h.smali','    const-string v9, "ar"\n',
     '    const-string v9, "ar"\n\n    invoke-static {v9}, '+L+'->geo(Ljava/lang/String;)Ljava/lang/String;\n\n    move-result-object v9\n')

# 6. saved names shown in UI
def tp_after(key, reg):
    old=f'    const-string {key[0]}, "{key[1]}"\n\n    invoke-interface {{v4, {key[0]}, v8}}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;\n\n    move-result-object {reg}\n'
    sub1('m1.1/j.smali', old, old+f'\n    invoke-static/range {{{reg} .. {reg}}}, {L}->tp(Ljava/lang/String;)Ljava/lang/String;\n\n    move-result-object {reg}\n')
tp_after(('v5','loc_name'),'v32')
tp_after(('v2','adhan_name'),'v47')
tp_after(('v2','ad_title'),'v2')
tp_after(('v2','ad_text'),'v2')

# 7. MainActivity: locale context + language card after Appearance
MA='com/nooralmehrab/app/MainActivity.smali'
sub1(MA, '.method public final onActivityResult(',
'''.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 0

    invoke-static {p1}, '''+L+'''->wrap(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method public final onActivityResult(''')
anchor='''    const-string v1, "\\u0627\\u0644\\u0645\\u0638\\u0647\\u0631"

    invoke-static/range {v1 .. v1}, '''+L+'''->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, p1, v1, v0}, Lcom/nooralmehrab/app/MainActivity;->h(Landroid/widget/LinearLayout;Ljava/lang/String;LB1/l;)V
'''
sub1(MA, anchor, anchor+'''
    new-instance v0, Lcom/nooralmehrab/app/LangSection;

    invoke-direct {v0, p0}, Lcom/nooralmehrab/app/LangSection;-><init>(Lcom/nooralmehrab/app/MainActivity;)V

    invoke-static {}, '''+L+'''->title()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, p1, v1, v0}, Lcom/nooralmehrab/app/MainActivity;->h(Landroid/widget/LinearLayout;Ljava/lang/String;LB1/l;)V
''')

# 8. background entry points load the language
sub1('com/nooralmehrab/app/notify/AlarmReceiver.smali',
     '.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V\n    .locals 11\n',
     '.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V\n    .locals 11\n\n    invoke-static {p1}, '+L+'->init(Landroid/content/Context;)V\n\n    invoke-static {p1}, Lcom/nooralmehrab/app/Updater;->background(Landroid/content/Context;)V\n\n    invoke-static {p1, p2}, Lcom/nooralmehrab/app/AdhkarNotify;->onAlarm(Landroid/content/Context;Landroid/content/Intent;)V\n\n    invoke-static {p1, p2}, Lcom/nooralmehrab/app/PrayerAlerts;->onAlarm(Landroid/content/Context;Landroid/content/Intent;)V\n')
sub1('com/nooralmehrab/app/notify/AdhanService.smali',
     '.method public final onStartCommand(Landroid/content/Intent;II)I\n    .locals 9\n',
     '.method public final onStartCommand(Landroid/content/Intent;II)I\n    .locals 9\n\n    invoke-static {p0}, '+L+'->init(Landroid/content/Context;)V\n')

# 9. manifest
mf=os.path.join(mod,'AndroidManifest.xml'); s=open(mf,encoding='utf-8').read()
anchor='<receiver android:exported="false" android:name="com.nooralmehrab.app.notify.AlarmReceiver"/>'
assert s.count(anchor)==1
s=s.replace(anchor,'<activity android:exported="false" android:excludeFromRecents="true" android:name="com.nooralmehrab.app.Restart" android:process=":restart" android:theme="@android:style/Theme.Translucent.NoTitleBar"/>\n        '+anchor)
open(mf,'w',encoding='utf-8').write(s)

# 10. picking a muezzin plays it right away (the service stops whatever was playing first)
sub1('k1.1/j.smali', """    invoke-virtual {v0, p2, p1}, Lcom/nooralmehrab/app/MainActivity;->y(ZLB1/l;)V
""", """    invoke-virtual {v0, p2, p1}, Lcom/nooralmehrab/app/MainActivity;->y(ZLB1/l;)V

    const-string v1, "\\u0635\\u0648\\u062a \\u0627\\u0644\\u0645\\u0624\\u0630\\u0646"

    invoke-static/range {v1 .. v1}, """+L+"""->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Ln1/b;->c(Landroid/content/Context;Ljava/lang/String;)Z
""")
print('done')
