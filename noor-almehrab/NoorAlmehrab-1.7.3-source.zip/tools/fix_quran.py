import json,unicodedata,sys
r=json.load(open('quran/quran.json',encoding='utf-8'))
R={(s['id'],v['id']):v['text'] for s in r for v in s['verses']}
d=json.load(open('quran/ara-quranuthmanihaf.json',encoding='utf-8'))
F={(v['chapter'],v['verse']):v['text'].replace('‏','').strip() for v in d['quran']}
def skel(t):
    t=unicodedata.normalize('NFKD',t)
    t=''.join(c for c in t if unicodedata.category(c)[0]=='L')
    for a,b in [('ٱ','ا'),('ى','ي'),('ة','ه'),('ؤ','و'),('ئ','ي'),('ء',''),('ـ','')]: t=t.replace(a,b)
    return t
manual={(2,72):[2],(44,33):[5],(37,164):[],(41,47):[]}
fixed={}
for k in F:
    if k in manual:
        w=F[k].split(' ')
        for idx in manual[k]:
            assert w[idx][-1] in '\u08F0\u08F1', (k, w[idx]); w[idx:idx+2]=[w[idx]+w[idx+1]]
        fixed[k]=' '.join(w); continue
    fw=F[k].split(' '); rw=R[k].split(); out=[];i=j=0
    while i<len(fw):
        tok=fw[i]
        if skel(tok)==skel(rw[j]) and not (tok.endswith('ࣰ') and i+1<len(fw) and skel(tok+fw[i+1])==skel(rw[j])):
            out.append(tok);i+=1;j+=1;continue
        merged=tok;m=i
        while m+1<len(fw) and merged[-1] in 'ࣰࣱࣲ' and skel(merged)!=skel(rw[j]):
            m+=1;merged+=fw[m]
        assert skel(merged)==skel(rw[j]),k
        out.append(merged);i=m+1;j+=1
    assert j==len(rw),k
    fixed[k]=' '.join(out)
# no open tanween may be followed by a space and then a bare alef/yeh-type letter fragment
import re
bad=[k for k,t in fixed.items() if re.search('[ࣰࣱࣲ] [اىيو]\\S{0,1}( |$)',t)]
print('suspicious left:',bad)
lines=[f"{s}|{v}|{fixed[(s,v)]}" for s in range(1,115) for v in range(1,10000) if (s,v) in fixed]
assert len(lines)==6236
open('assets/quran.txt','w',encoding='utf-8').write('\n'.join(lines)+'\n')
print('ok', fixed[(2,2)][:40])
