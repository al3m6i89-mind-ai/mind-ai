import os,sys
mod=sys.argv[1]
S=os.path.join(mod,'smali')
L='Lcom/nooralmehrab/app/L10n;'
F='Lcom/nooralmehrab/app/'
MA='com/nooralmehrab/app/MainActivity.smali'
def rd(p): return open(os.path.join(S,p),encoding='utf-8').read()
def wr(p,s): open(os.path.join(S,p),'w',encoding='utf-8').write(s)
def sub1(p, old, new):
    s=rd(p); n=s.count(old)
    assert n==1, (p, old[:90], n)
    wr(p, s.replace(old,new))

# 11. "More" card (Khatma, Ruqyah, mosques) on the prayer-times tab
anchor = (":goto_32\n"
"    invoke-static {v5, v5, v1, v15, v0}, LA0/a;->A(IIFII)Landroid/widget/LinearLayout$LayoutParams;\n\n"
"    move-result-object v3\n\n"
"    invoke-static {v13, v11, v3}, LA0/a;->a(Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/LinearLayout$LayoutParams;)V\n")
sub1(MA, anchor, anchor+"\n    invoke-static {v7, v13}, "+F+"Features;->home(Lcom/nooralmehrab/app/MainActivity;Landroid/widget/LinearLayout;)V\n")

# 12. settings cards
H="    invoke-virtual {p0, p1, v1, v0}, Lcom/nooralmehrab/app/MainActivity;->h(Landroid/widget/LinearLayout;Ljava/lang/String;LB1/l;)V\n"
def esc(t): return ''.join(c if ord(c)<128 else '\\u%04x'%ord(c) for c in t)
def section_after(label_escaped, cls):
    label_escaped=esc(label_escaped)
    a2=('    const-string v1, "'+label_escaped+'"\n\n'
        '    invoke-static/range {v1 .. v1}, '+L+'->t(Ljava/lang/String;)Ljava/lang/String;\n\n'
        '    move-result-object v1\n\n'+H)
    sub1(MA, a2, a2+'\n    new-instance v0, '+F+cls+';\n\n'
         '    invoke-direct {v0, p0}, '+F+cls+';-><init>(Lcom/nooralmehrab/app/MainActivity;)V\n\n'
         '    invoke-static {}, '+F+cls+';->title()Ljava/lang/String;\n\n'
         '    move-result-object v1\n\n'+H)
section_after(r'الصوت والإشعارات', 'Features$FlipCard')
section_after(r'التاريخ الهجري', 'Features$UpdateCard')
foot=('    const-string v8, "'+esc(r'نور المحراب • الإصدار 1.0')+'"\n\n'
      '    invoke-static/range {v8 .. v8}, '+L+'->t(')
sub1(MA, foot, foot.replace(L+'->t(', F+'Features;->footer('))

# 13. flip-to-stop while the Adhan plays / after alerts
AS='com/nooralmehrab/app/notify/AdhanService.smali'
sub1(AS, '    sput-boolean v2, Lcom/nooralmehrab/app/notify/AdhanService;->q:Z\n',
     '    sput-boolean v2, Lcom/nooralmehrab/app/notify/AdhanService;->q:Z\n\n    invoke-static {p0}, '+F+'FlipStop;->onAdhan(Landroid/content/Context;)V\n')
sub1(AS, '.method public final a()V\n    .locals 2\n', '.method public final a()V\n    .locals 2\n\n    invoke-static {}, '+F+'FlipStop;->stop()V\n')
sub1('n1.1/b.smali', '.method public static a(Landroid/content/Context;Lm1/d;Z)V\n    .locals 3\n',
     '.method public static a(Landroid/content/Context;Lm1/d;Z)V\n    .locals 3\n\n    invoke-static {p0}, '+F+'FlipStop;->onAlert(Landroid/content/Context;)V\n')
sub1('n1.1/b.smali', '.method public b(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Z)V\n    .locals 2\n',
     '.method public b(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Z)V\n    .locals 2\n\n    invoke-static {p1}, '+F+'FlipStop;->onAlert(Landroid/content/Context;)V\n')

# 14. update check + adhkar schedule on every resume
sub1(MA, '    invoke-super {p0}, Landroid/app/Activity;->onResume()V\n',
     '    invoke-super {p0}, Landroid/app/Activity;->onResume()V\n\n    invoke-static {p0}, '+F+'Guard;->guard(Landroid/app/Activity;)V\n\n    invoke-static {p0}, '+F+'Updater;->onResume(Landroid/app/Activity;)V\n\n    invoke-static {p0}, '+F+'AdhkarNotify;->schedule(Landroid/content/Context;)V\n')

# 15. manifest: installer permission + receiver
mf=os.path.join(mod,'AndroidManifest.xml'); s=open(mf,encoding='utf-8').read()
a1='<uses-permission android:name="android.permission.VIBRATE"/>'
assert s.count(a1)==1
s=s.replace(a1, a1+'\n    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>')
a2='<receiver android:exported="false" android:name="com.nooralmehrab.app.notify.AlarmReceiver"/>'
assert s.count(a2)==1
# Add adhkar intent-filter actions to AlarmReceiver
a2_new=('<receiver android:exported="false" android:name="com.nooralmehrab.app.notify.AlarmReceiver">\n'
        '            <intent-filter>\n'
        '                <action android:name="com.nooralmehrab.app.ADHKAR_MORNING"/>\n'
        '                <action android:name="com.nooralmehrab.app.ADHKAR_EVENING"/>\n'
        '                <action android:name="com.nooralmehrab.app.PRE_PRAYER"/>\n'
        '            </intent-filter>\n'
        '        </receiver>')
widget_receiver=('\n        <receiver android:exported="true" android:name="com.nooralmehrab.app.PrayerWidget">\n'
        '            <intent-filter>\n'
        '                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>\n'
        '            </intent-filter>\n'
        '            <meta-data android:name="android.appwidget.provider"\n'
        '                android:resource="@xml/widget_info"/>\n'
        '        </receiver>')
s=s.replace(a2, '<receiver android:exported="false" android:name="com.nooralmehrab.app.InstallReceiver"/>\n        '+a2_new+widget_receiver)
open(mf,'w',encoding='utf-8').write(s)

# 15e. Widget resource files
import shutil, os as _os
wr_src = _os.path.join(_os.path.dirname(__file__), 'widget_res')
shutil.copy(_os.path.join(wr_src,'layout','widget_prayer.xml'), _os.path.join(mod,'res','layout','widget_prayer.xml'))
_os.makedirs(_os.path.join(mod,'res','xml'), exist_ok=True)
shutil.copy(_os.path.join(wr_src,'xml','widget_info.xml'), _os.path.join(mod,'res','xml','widget_info.xml'))

# 15b. Firebase: string resources so FirebaseInitProvider auto-initialises
import json
gs=json.load(open(os.path.join(os.path.dirname(__file__),'google-services.json'),encoding='utf-8'))
pi=gs['project_info']; cl=gs['client'][0]
fb={
 'google_app_id': cl['client_info']['mobilesdk_app_id'],
 'gcm_defaultSenderId': pi['project_number'],
 'google_api_key': cl['api_key'][0]['current_key'],
 'google_crash_reporting_api_key': cl['api_key'][0]['current_key'],
 'project_id': pi['project_id'],
 'google_storage_bucket': pi['storage_bucket'],
}
sx=os.path.join(mod,'res','values','strings.xml'); st=open(sx,encoding='utf-8').read()
for k,v in fb.items():
    assert 'name="%s"'%k not in st, k
ins=''.join('    <string name="%s" translatable="false">%s</string>\n'%(k,v) for k,v in fb.items())
assert st.count('</resources>')==1
st=st.replace('</resources>', ins+'</resources>')
open(sx,'w',encoding='utf-8').write(st)

# 15d. muezzin picker -> AdhanPick.pick (adds "choose from phone" as first option)
F2 = 'Lcom/nooralmehrab/app/'
anchor_pick = ('    filled-new-array {v4, v7, v8, v6}, [Ljava/lang/String;\n\n'
               '    move-result-object v4\n')
sub1('k1.1/c.smali', anchor_pick, anchor_pick +
     '\n    invoke-static {v5, v4, p1}, ' + F2 + 'AdhanPick;->pick(Lcom/nooralmehrab/app/MainActivity;[Ljava/lang/String;[Ljava/lang/String;)V\n\n'
     '    return-void\n')

# forward onActivityResult to AdhanPick (custom sound file result)
sub1(MA, '    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V\n',
     '    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V\n\n'
     '    invoke-static {p0, p1, p2, p3}, ' + F2 + 'AdhanPick;->onResult(Lcom/nooralmehrab/app/MainActivity;IILandroid/content/Intent;)V\n')

# 15c. optional: swap the interstitial ad unit for Google's official TEST id
# (local verification only; enabled with TEST_ADS=1, never for a release build)
if os.environ.get('TEST_ADS') == '1':
    real = 'ca-app-pub-8031181800607669/7836722360'
    test = 'ca-app-pub-3940256099942544/1033173712'
    for p in ['com/nooralmehrab/app/MainActivity.smali', 'l1.1/g.smali']:
        s = rd(p); assert s.count(real) == 1, (p, 'real-ad-id', s.count(real))
        wr(p, s.replace(real, test))
    print('TEST_ADS: interstitial id swapped to Google test id')

# 16. version
y=os.path.join(mod,'apktool.yml'); t=open(y).read()
assert 'versionCode: 2' in t and 'versionName: 1.1.0' in t
t=t.replace('versionCode: 2','versionCode: '+os.environ['VCODE']).replace('versionName: 1.1.0','versionName: '+os.environ['VNAME'])
open(y,'w').write(t)
print('patch2 done')
