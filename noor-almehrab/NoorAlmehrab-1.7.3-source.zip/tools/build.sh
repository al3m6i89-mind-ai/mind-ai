set -e
W=/tmp/claude-0/w
: "${VCODE:=3}" "${VNAME:=1.2.0}" "${UPDATE_URL:=}"
export VCODE VNAME
BUILT=$(TZ=Asia/Riyadh date '+%Y-%m-%d %H:%M')
cd $W
python3 -I tools/gen_l10n.py tools strings.json tools/L10n.java.tpl > java/src/com/nooralmehrab/app/L10n.java
sed -e "s|@VERSION@|$VNAME|" -e "s|@BUILT@|$BUILT|" -e "s|@UPDATE_URL@|${UPDATE_URL//&/\\&}|" tools/BuildInfo.java.tpl > java/src/com/nooralmehrab/app/BuildInfo.java
cd java && rm -rf out stubout dexin smaliout tmpapk x.apk new.dex && mkdir -p out stubout tmpapk
javac -nowarn -encoding UTF-8 --release 8 -cp ../android-all-14-robolectric-10818077.jar -d stubout $(find stubs -name '*.java') 2>&1 | grep -v 'JAVA_TOOL\|^Note' || true
javac -Xlint:none -encoding UTF-8 --release 8 -cp ../android-all-14-robolectric-10818077.jar:stubout -d out $(find src -name '*.java') 2>&1 | grep -v 'JAVA_TOOL\|^Note\|warning: \[options\]\|^1 warning' || true
java -cp ../dalvik-dx-14.0.0_r21.jar com.android.dx.command.Main --dex --min-sdk-version=26 --output=new.dex out
cp new.dex tmpapk/classes.dex && (cd tmpapk && zip -q ../x.apk classes.dex)
java -jar ../apktool.jar d -r -f x.apk -o smaliout >/dev/null 2>&1
cd $W && rm -rf mod && cp -r orig mod && rm -rf mod/build
python3 -I tools/patch.py mod files.txt java/smaliout/smali/com/nooralmehrab/app
python3 -I tools/patch2.py mod
mkdir -p mod/res/values-en mod/assets && cp tools/values-en.xml mod/res/values-en/strings.xml && cp assets/quran.txt assets/surahs.txt assets/hafs.ttf mod/assets/
rm -rf unsigned.apk signed && java -jar apktool.jar b mod -o unsigned.apk 2>&1 | grep -v JAVA_TOOL | tail -1
PW=$(cat ks.pass)
java -jar uas.jar -a unsigned.apk --ks noor-release.jks --ksAlias noor --ksPass "$PW" --ksKeyPass "$PW" -o signed 2>&1 | grep -E 'verified|error'
echo "BUILT=$BUILT"
