package com.nooralmehrab.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/** Result of an in-app update install: opens the system confirmation, or reports a failure. */
public final class InstallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = (Intent) i.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    c.startActivity(confirm);
                } catch (Throwable ignored) {
                }
            }
        } else if (status != PackageInstaller.STATUS_SUCCESS) {
            L10n.init(c);
            Ui.toast(c, Ui.s("لم يكتمل تثبيت التحديث، حاول مرة أخرى.", "The update wasn't installed. Please try again."));
        }
    }
}
