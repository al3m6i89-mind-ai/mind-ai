package com.nooralmehrab.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

/** Daily prayer tracking — marks which of the five prayers were performed. */
public final class PrayerLog {
    private PrayerLog() {}

    private static final String PREF = "prayer_log";
    private static final String[] NAMES_AR = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final String[] NAMES_EN = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private static final String[] KEYS = {"fajr", "dhuhr", "asr", "maghrib", "isha"};

    public static void open(final MainActivity a) {
        p1.c p = Ui.pal(a);
        final SharedPreferences sp = a.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        final String today = todayKey();
        final boolean[] done = new boolean[5];
        for (int i = 0; i < 5; i++) done[i] = sp.getBoolean(today + "_" + KEYS[i], false);

        int bg = p.a ? 0xFF1A1A2E : 0xFFF5F5F5;
        int cardBg = p.a ? 0xFF252540 : 0xFFFFFFFF;
        int textColor = p.a ? 0xFFEEEEEE : 0xFF1A1A1A;
        int accent = p.b;
        int doneColor = 0xFF4CAF50;
        int undoneColor = p.a ? 0xFF555577 : 0xFFCCCCCC;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));

        // Date header
        TextView dateView = new TextView(a);
        dateView.setText(todayArabic());
        dateView.setTextColor(p.a ? 0xFF9999BB : 0xFF666666);
        dateView.setTextSize(13f);
        dateView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.setMargins(0, 0, 0, dp(a, 20));
        dateView.setLayoutParams(dlp);
        root.addView(dateView);

        // Summary bar
        final TextView summaryView = new TextView(a);
        summaryView.setTextSize(14f);
        summaryView.setGravity(Gravity.CENTER);
        summaryView.setTextColor(textColor);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.setMargins(0, 0, 0, dp(a, 20));
        summaryView.setLayoutParams(slp);
        root.addView(summaryView);

        final View[] rows = new View[5];
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            int rp = dp(a, 14);
            row.setPadding(rp, rp, rp, rp);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(a, 8));
            row.setLayoutParams(rlp);
            rows[i] = row;

            // Prayer name
            TextView name = new TextView(a);
            name.setText(L10n.en() ? NAMES_EN[i] : NAMES_AR[i]);
            name.setTextSize(17f);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(textColor);
            name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(name);

            // Check button
            final TextView check = new TextView(a);
            check.setTextSize(18f);
            check.setGravity(Gravity.CENTER);
            check.setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            check.setLayoutParams(clp);
            row.addView(check);

            // Update appearance
            final boolean[] state = {done[i]};
            final Runnable updateRow = new Runnable() {
                @Override public void run() {
                    check.setText(state[0] ? "✓" : "○");
                    check.setTextColor(state[0] ? doneColor : undoneColor);
                    try {
                        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                        gd.setColor(state[0] ? 0x224CAF50 : (p.a ? 0x11FFFFFF : 0x11000000));
                        gd.setCornerRadius(dp(a, 10));
                        row.setBackground(gd);
                    } catch (Throwable ignored) {}
                    // update summary
                    int cnt = 0;
                    for (boolean d : done) if (d) cnt++;
                    summaryView.setText(Ui.s(cnt + " / 5 صلوات ✓", cnt + " / 5 prayers ✓"));
                    summaryView.setTextColor(cnt == 5 ? doneColor : textColor);
                }
            };
            updateRow.run();

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    state[0] = !state[0];
                    done[idx] = state[0];
                    sp.edit().putBoolean(today + "_" + KEYS[idx], state[0]).apply();
                    updateRow.run();
                }
            });

            root.addView(row);
        }

        new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("تتبع صلواتي", "My Prayer Log"))
            .setView(root)
            .setNegativeButton(Ui.s("إغلاق", "Close"), null)
            .show();
    }

    private static String todayKey() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) + "_" + c.get(Calendar.DAY_OF_YEAR);
    }

    private static String todayArabic() {
        Calendar c = Calendar.getInstance();
        int d = c.get(Calendar.DAY_OF_MONTH);
        int m = c.get(Calendar.MONTH) + 1;
        int y = c.get(Calendar.YEAR);
        if (L10n.en()) return d + "/" + m + "/" + y;
        return Ui.n(d) + "/" + Ui.n(m) + "/" + Ui.n(y);
    }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
