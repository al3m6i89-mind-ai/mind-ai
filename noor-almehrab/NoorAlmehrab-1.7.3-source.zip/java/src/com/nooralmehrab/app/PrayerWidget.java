package com.nooralmehrab.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Home-screen widget showing the app name and a tap-to-open button.
 * The widget layout (widget_prayer.xml) is placed in res/layout by patch2.py.
 * Widget info (widget_info.xml) is placed in res/xml by patch2.py.
 */
public final class PrayerWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) updateWidget(ctx, mgr, id);
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        ComponentName cn = new ComponentName(ctx, PrayerWidget.class);
        int[] ids = mgr.getAppWidgetIds(cn);
        for (int id : ids) updateWidget(ctx, mgr, id);
    }

    private static void updateWidget(Context ctx, AppWidgetManager mgr, int widgetId) {
        try {
            RemoteViews rv = new RemoteViews(ctx.getPackageName(), getLayoutId(ctx));
            // App title
            rv.setTextViewText(getTitleId(ctx), ctx.getString(getStringId(ctx, "app_name")));
            // "Open app" tap intent
            Intent launch = new Intent(ctx, MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(ctx, 0, launch,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT |
                (android.os.Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0));
            rv.setOnClickPendingIntent(getRootId(ctx), pi);
            mgr.updateAppWidget(widgetId, rv);
        } catch (Throwable ignored) {}
    }

    /** Refresh all widget instances — called from AlarmReceiver. */
    public static void refresh(Context ctx) {
        try {
            ctx.sendBroadcast(new Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .setComponent(new ComponentName(ctx, PrayerWidget.class)));
        } catch (Throwable ignored) {}
    }

    // --- resource id lookups (avoids compile-time R dependency) ---

    private static int getLayoutId(Context ctx) {
        return ctx.getResources().getIdentifier("widget_prayer", "layout", ctx.getPackageName());
    }

    private static int getTitleId(Context ctx) {
        return ctx.getResources().getIdentifier("widget_title", "id", ctx.getPackageName());
    }

    private static int getRootId(Context ctx) {
        return ctx.getResources().getIdentifier("widget_root", "id", ctx.getPackageName());
    }

    private static int getStringId(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "string", ctx.getPackageName());
    }
}
