package com.nooralmehrab.app;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Sunrise (الشروق) and sunset (الغروب) for a given location and day, using the
 * standard sunrise equation (NOAA). Returns epoch milliseconds in UTC, which are
 * then shown in the device's local time.
 */
final class SunTimes {
    private SunTimes() {}

    static final int NEVER = Integer.MIN_VALUE;

    /** { sunriseMs, sunsetMs } in UTC epoch millis, or null if the sun does not rise/set today. */
    static long[] today(double lat, double lng) {
        double jnow = System.currentTimeMillis() / 86400000.0 + 2440587.5;
        double n = Math.floor(jnow - 2451545.0 + 0.0008 + 0.5);
        double jstar = n - lng / 360.0;
        double M = mod(357.5291 + 0.98560028 * jstar, 360);
        double Mr = Math.toRadians(M);
        double C = 1.9148 * Math.sin(Mr) + 0.0200 * Math.sin(2 * Mr) + 0.0003 * Math.sin(3 * Mr);
        double lambda = mod(M + C + 180 + 102.9372, 360);
        double lr = Math.toRadians(lambda);
        double jtransit = 2451545.0 + jstar + 0.0053 * Math.sin(Mr) - 0.0069 * Math.sin(2 * lr);
        double delta = Math.asin(Math.sin(lr) * Math.sin(Math.toRadians(23.4397)));
        double latr = Math.toRadians(lat);
        double cosH = (Math.sin(Math.toRadians(-0.833)) - Math.sin(latr) * Math.sin(delta))
                / (Math.cos(latr) * Math.cos(delta));
        if (cosH > 1 || cosH < -1) return null; // polar day/night
        double H = Math.toDegrees(Math.acos(cosH));
        double jrise = jtransit - H / 360.0;
        double jset = jtransit + H / 360.0;
        return new long[]{ jToMs(jrise), jToMs(jset) };
    }

    private static long jToMs(double j) {
        return Math.round((j - 2440587.5) * 86400000.0);
    }

    private static double mod(double a, double b) {
        return a - b * Math.floor(a / b);
    }

    /** Local time like "٦:١٢ ص" (Arabic) or "6:12 AM" (English). */
    static String fmt(long ms) {
        Calendar c = Calendar.getInstance(TimeZone.getDefault());
        c.setTimeInMillis(ms);
        int h = c.get(Calendar.HOUR_OF_DAY);
        int min = c.get(Calendar.MINUTE);
        boolean pm = h >= 12;
        int h12 = h % 12;
        if (h12 == 0) h12 = 12;
        String mm = (min < 10 ? "0" : "") + min;
        if (L10n.en()) return h12 + ":" + mm + (pm ? " PM" : " AM");
        StringBuilder am = new StringBuilder();
        for (char ch : mm.toCharArray()) am.append((char) ('٠' + (ch - '0')));
        return Ui.n(h12) + ":" + am + (pm ? " م" : " ص");
    }
}
