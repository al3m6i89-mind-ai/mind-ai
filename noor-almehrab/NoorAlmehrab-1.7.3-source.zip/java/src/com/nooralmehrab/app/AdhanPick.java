package com.nooralmehrab.app;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.View;

/**
 * The muezzin-sound picker. It keeps the app's four built-in adhans and adds, as the
 * first option, "choose a sound from the phone" so the user can set any audio file on
 * the device as the adhan. The chosen file's URI is stored the same way the built-in
 * sounds are, and the adhan service already plays an arbitrary URI.
 */
public final class AdhanPick {
    private AdhanPick() {}

    static final int REQ = 0x4E07;

    /** Called in place of the app's own "choose adhan" dialog. */
    public static void pick(final MainActivity a, final String[] uris, final String[] names) {
        try {
            p1.c p = Ui.pal(a);
            final String custom = Ui.s("🎵 اختيار صوت من الجهاز", "🎵 Choose a sound from the phone");
            String[] items = new String[names.length + 1];
            items[0] = custom;
            System.arraycopy(names, 0, items, 1, names.length);
            android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, p.a ? 4 : 5)
                    .setTitle(Ui.s("اختر صوت المؤذن", "Choose the adhan sound"))
                    .setItems(items, new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int which) {
                            if (which == 0) launch(a);
                            else apply(a, uris[which - 1], names[which - 1]);
                        }
                    });
            android.app.AlertDialog d = b.show();
            if (d.getWindow() != null) {
                L10n.dir(d.getWindow().getDecorView(), View.LAYOUT_DIRECTION_RTL);
            }
        } catch (Throwable t) {
            Ui.toast(a, Ui.s("تعذّر فتح قائمة الأصوات", "Couldn't open the sound list"));
        }
    }

    /** Opens the phone's own audio library / music player so a track can be picked. */
    private static void launch(MainActivity a) {
        try {
            Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
            i.setType("audio/*");
            a.startActivityForResult(i, REQ);
            return;
        } catch (Throwable ignored) {
        }
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/*");
            a.startActivityForResult(Intent.createChooser(i, Ui.s("اختر صوتاً", "Choose a sound")), REQ);
        } catch (Throwable t) {
            Ui.toast(a, Ui.s("تعذّر فتح مشغل الصوت", "Couldn't open the audio player"));
        }
    }

    /** MainActivity.onActivityResult */
    public static void onResult(final MainActivity a, int req, int res, Intent data) {
        if (req != REQ) return;
        if (res != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final String name = displayName(a, uri);
        Ui.toast(a, Ui.s("جارٍ تجهيز الصوت…", "Preparing the sound…"));
        // Copy into the app's private storage so the adhan can always play it, with no permission needed.
        new Thread(new Runnable() {
            @Override public void run() {
                String saved = null;
                try {
                    java.io.File dir = new java.io.File(a.getFilesDir(), "adhan");
                    dir.mkdirs();
                    java.io.File[] old = dir.listFiles();
                    if (old != null) for (java.io.File f : old) f.delete();
                    java.io.File out = new java.io.File(dir, "custom_" + System.currentTimeMillis() + ".mp3");
                    java.io.InputStream in = a.getContentResolver().openInputStream(uri);
                    java.io.OutputStream os = new java.io.FileOutputStream(out);
                    byte[] buf = new byte[65536];
                    long total = 0;
                    int n;
                    while (in != null && (n = in.read(buf)) > 0) {
                        total += n;
                        if (total > 40L * 1024 * 1024) throw new Exception("too big");
                        os.write(buf, 0, n);
                    }
                    os.close();
                    if (in != null) in.close();
                    if (total > 0) saved = Uri.fromFile(out).toString();
                } catch (Throwable ignored) {
                }
                final String result = saved;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (result == null) {
                            Ui.toast(a, Ui.s("تعذّر اختيار الصوت، جرّب ملفاً آخر.", "Couldn't use that sound, try another file."));
                            return;
                        }
                        apply(a, result, name);
                        Ui.toast(a, Ui.s("تم اختيار الصوت ✓", "Sound selected ✓"));
                    }
                });
            }
        }).start();
    }

    private static String displayName(MainActivity a, Uri uri) {
        String name = Ui.s("صوت مخصص", "Custom sound");
        Cursor c = null;
        try {
            c = a.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) {
                    String n = c.getString(idx);
                    if (n != null && n.length() > 0) {
                        int dot = n.lastIndexOf('.');
                        name = dot > 0 ? n.substring(0, dot) : n;
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Throwable ignored) {}
        }
        return name;
    }

    /** Stores the chosen sound through the app's own settings path (adhanUri + adhanName). */
    private static void apply(MainActivity a, String uri, String name) {
        try {
            n1.b.d(a);
        } catch (Throwable ignored) {}
        try {
            a.y(true, new k1.v(new String[]{uri}, 0, new String[]{name}));
        } catch (Throwable t) {
            Ui.toast(a, Ui.s("تعذّر حفظ الصوت", "Couldn't save the sound"));
        }
    }
}
