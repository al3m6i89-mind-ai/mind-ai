package com.nooralmehrab.app;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.widget.Toast;

import java.security.MessageDigest;

/**
 * Tamper check: verifies at runtime that the app is still signed with the
 * original Noor Al-Mehrab release certificate. If someone decompiles the app,
 * changes it and re-signs it with a different key, the signature no longer
 * matches and the app refuses to run. It cannot make modification impossible,
 * but it means a modified copy will not simply start.
 */
public final class Guard {
    private Guard() {}

    /** SHA-256 of the release signing certificate (upper-case hex, no separators). */
    private static final String CERT =
        "04C26CD296A3054A3D9517B5C5181C5D67E9DA95F3C86AED2EE076C5DF822A92";

    private static Boolean ok;

    /** True when the app carries the genuine release signature. */
    public static synchronized boolean genuine(Context c) {
        if (ok != null) return ok;
        ok = Boolean.TRUE;
        try {
            Signature[] sigs;
            PackageManager pm = c.getPackageManager();
            String pkg = c.getPackageName();
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.getApkContentsSigners();
            } else {
                PackageInfo pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            boolean match = false;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            for (Signature s : sigs) {
                byte[] h = md.digest(s.toByteArray());
                StringBuilder b = new StringBuilder(h.length * 2);
                for (byte x : h) {
                    b.append(Character.forDigit((x >> 4) & 0xF, 16));
                    b.append(Character.forDigit(x & 0xF, 16));
                }
                if (CERT.equalsIgnoreCase(b.toString())) { match = true; break; }
            }
            ok = match;
        } catch (Throwable t) {
            // If the platform cannot report signatures, do not brick a genuine install.
            ok = Boolean.TRUE;
        }
        return ok;
    }

    /** Called at startup: a tampered copy shows a notice and closes. */
    public static void guard(Activity a) {
        try {
            if (genuine(a)) return;
            Toast.makeText(a, L10n.en()
                ? "This copy of the app has been modified and cannot run."
                : "هذه النسخة من التطبيق معدّلة ولا يمكن تشغيلها.",
                Toast.LENGTH_LONG).show();
            a.finishAffinity();
        } catch (Throwable ignored) {
        }
    }
}
