package com.nooralmehrab.app;

import android.app.NotificationManager;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/** Stops the Adhan and alert sounds when the phone is turned face down. */
public final class FlipStop implements SensorEventListener {
    private static FlipStop active;

    private final Context app;
    private final SensorManager sm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean wasUp;
    private long downSince;

    private FlipStop(Context app, SensorManager sm) {
        this.app = app;
        this.sm = sm;
    }

    /** The Adhan started playing: watch until it stops (at most 15 minutes). */
    public static void onAdhan(Context c) {
        start(c, 15 * 60 * 1000L);
    }

    /** An alert notification was posted: watch for a minute. */
    public static void onAlert(Context c) {
        start(c, 60 * 1000L);
    }

    private static synchronized void start(Context c, long ms) {
        try {
            if (c == null || !Features.flipOn(c)) return;
            Context app = c.getApplicationContext();
            if (active == null) {
                SensorManager sm = (SensorManager) app.getSystemService(Context.SENSOR_SERVICE);
                if (sm == null) return;
                Sensor s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                if (s == null) return;
                FlipStop f = new FlipStop(app, sm);
                sm.registerListener(f, s, SensorManager.SENSOR_DELAY_NORMAL, f.handler);
                active = f;
            }
            final FlipStop f = active;
            f.handler.removeCallbacksAndMessages(null);
            f.handler.postDelayed(new Runnable() {
                @Override public void run() { stop(); }
            }, ms);
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void stop() {
        FlipStop f = active;
        active = null;
        if (f == null) return;
        try {
            f.handler.removeCallbacksAndMessages(null);
            f.sm.unregisterListener(f);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float z = e.values[2];
        if (z > 3f) {
            // Face up (or held up) first, so a phone already lying face down doesn't cut the Adhan at once.
            wasUp = true;
            downSince = 0;
        } else if (z < -8f && wasUp) {
            long now = SystemClock.elapsedRealtime();
            if (downSince == 0) downSince = now;
            else if (now - downSince > 400) trigger();
        } else {
            downSince = 0;
        }
    }

    private void trigger() {
        stop();
        try {
            n1.b.d(app);
        } catch (Throwable ignored) {
        }
        try {
            NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancelAll();
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
