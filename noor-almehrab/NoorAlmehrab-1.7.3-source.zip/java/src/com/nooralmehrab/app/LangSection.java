package com.nooralmehrab.app;

import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.util.List;

/** Builds the language card body in Settings, reusing the app's segmented control (same look as Appearance). */
public final class LangSection implements B1.l {
    private final MainActivity act;

    public LangSection(MainActivity act) { this.act = act; }

    @Override
    public Object h(Object o) {
        LinearLayout card = (LinearLayout) o;
        m1.h[] v = m1.h.values();
        List<q1.c> opts = new ArrayList<>();
        opts.add(new q1.c(v[0], "العربية"));
        opts.add(new q1.c(v[1], "English"));
        Enum cur = L10n.en() ? v[1] : v[0];
        LinearLayout row = act.a(opts, cur, new LangPick(act));
        A0.a.a(card, (View) row, A0.a.A(0, 0, 0f, 0, 15));
        return q1.g.a;
    }
}
