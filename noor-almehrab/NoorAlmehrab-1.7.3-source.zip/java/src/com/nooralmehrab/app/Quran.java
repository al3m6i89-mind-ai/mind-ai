package com.nooralmehrab.app;

import android.content.Context;
import android.graphics.Typeface;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Quran text of the King Fahd Complex (Hafs, version 13) bundled in assets/quran.txt as
 * "surah|ayah|text" lines, shown with the Complex's own Uthmanic Hafs font (assets/hafs.ttf).
 * In that font Arabic-Indic digits are drawn as ayah-end markers.
 */
final class Quran {
    private Quran() {}

    /** First surah and ayah of each of the 30 ajza'. */
    static final int[][] JUZ = {
        {1, 1}, {2, 142}, {2, 253}, {3, 93}, {4, 24}, {4, 148}, {5, 82}, {6, 111}, {7, 88}, {8, 41},
        {9, 93}, {11, 6}, {12, 53}, {15, 1}, {17, 1}, {18, 75}, {21, 1}, {23, 1}, {25, 21}, {27, 56},
        {29, 46}, {33, 31}, {36, 28}, {39, 32}, {41, 47}, {46, 1}, {51, 31}, {58, 1}, {67, 1}, {78, 1},
    };

    static String[][] ayat;      // [surah-1][ayah-1]
    static String[] nameAr = new String[114];
    static String[] nameEn = new String[114];
    static boolean[] meccan = new boolean[114];
    static Typeface font;

    static synchronized void load(Context c) throws Exception {
        if (ayat != null) return;
        String[][] a = new String[114][];
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("surahs.txt"), "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            if (line.isEmpty()) continue;
            String[] f = line.split("\\|");
            int s = Integer.parseInt(f[0]) - 1;
            nameAr[s] = f[1];
            nameEn[s] = f[2];
            a[s] = new String[Integer.parseInt(f[3])];
            meccan[s] = "meccan".equals(f[4]);
        }
        r.close();
        r = new BufferedReader(new InputStreamReader(c.getAssets().open("quran.txt"), "UTF-8"), 1 << 16);
        while ((line = r.readLine()) != null) {
            if (line.isEmpty()) continue;
            int p1 = line.indexOf('|'), p2 = line.indexOf('|', p1 + 1);
            int s = Integer.parseInt(line.substring(0, p1)) - 1;
            int v = Integer.parseInt(line.substring(p1 + 1, p2)) - 1;
            a[s][v] = line.substring(p2 + 1);
        }
        r.close();
        try {
            font = Typeface.createFromAsset(c.getAssets(), "hafs.ttf");
        } catch (Throwable t) {
            font = null;
        }
        ayat = a;
    }

    static String surahName(int s) {
        return L10n.en() ? nameEn[s - 1] : nameAr[s - 1];
    }

    /** Verses from (s, from) to (s, to) inclusive, each followed by its ayah-end marker. */
    static String range(int s, int from, int to) {
        StringBuilder b = new StringBuilder();
        for (int v = from; v <= to; v++) {
            if (b.length() > 0) b.append(' ');
            b.append(ayat[s - 1][v - 1]).append(' ').append(Ui.ar(v));
        }
        return b.toString();
    }

    static int count(int s) {
        return ayat[s - 1].length;
    }
}
