package com.nooralmehrab.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

/**
 * Schedules daily morning (6:00) and evening (16:00) adhkar reminders,
 * and an optional pre-prayer alert (15 minutes before each prayer).
 * Alarms are set from MainActivity.onResume so they stay active after reboot
 * (AlarmReceiver re-schedules them too).
 */
public final class AdhkarNotify {
    private AdhkarNotify() {}

    static final int MORNING_ID  = 8001;
    static final int EVENING_ID  = 8002;
    static final String CHANNEL  = "noor_adhkar";

    private static final String ACTION_MORNING = "com.nooralmehrab.app.ADHKAR_MORNING";
    private static final String ACTION_EVENING = "com.nooralmehrab.app.ADHKAR_EVENING";

    /** Called from MainActivity.onResume — sets up channel and schedules both alarms once per day. */
    public static void schedule(Context ctx) {
        createChannel(ctx);
        scheduleDailyAt(ctx, 6,  0, MORNING_ID, ACTION_MORNING);
        scheduleDailyAt(ctx, 16, 0, EVENING_ID, ACTION_EVENING);
    }

    /** Called from AlarmReceiver with the broadcast intent. */
    public static void onAlarm(Context ctx, android.content.Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (!ACTION_MORNING.equals(action) && !ACTION_EVENING.equals(action)) return;
        boolean morning = ACTION_MORNING.equals(action);
        String title = morning
            ? Ui.s("حان وقت أذكار الصباح", "Morning Adhkar time")
            : Ui.s("حان وقت أذكار المساء", "Evening Adhkar time");
        String body  = morning
            ? Ui.s("لا تنسَ أذكارك", "Don't forget your morning remembrance")
            : Ui.s("لا تنسَ أذكارك", "Don't forget your evening remembrance");
        showNotification(ctx, morning ? MORNING_ID : EVENING_ID, title, body);
    }

    private static void scheduleDailyAt(Context ctx, int hour, int minute, int reqId, String action) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(action);
            i.setClassName(ctx, "com.nooralmehrab.app.notify.AlarmReceiver");
            PendingIntent pi = PendingIntent.getBroadcast(ctx, reqId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (Throwable ignored) {}
    }

    static void showNotification(Context ctx, int id, String title, String body) {
        try {
            createChannel(ctx);
            android.app.Notification.Builder nb;
            if (Build.VERSION.SDK_INT >= 26) {
                nb = new android.app.Notification.Builder(ctx, CHANNEL);
            } else {
                nb = new android.app.Notification.Builder(ctx);
                try { nb.getClass().getMethod("setPriority", int.class).invoke(nb, 1); } catch (Throwable ignored2) {}
            }
            nb.setContentTitle(title)
              .setContentText(body)
              .setSmallIcon(android.R.drawable.ic_dialog_info)
              .setAutoCancel(true);
            Intent launch = new Intent(ctx, MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, id, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            nb.setContentIntent(pi);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, nb.build());
        } catch (Throwable ignored) {}
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL,
                        Ui.s("تذكير الأذكار", "Adhkar Reminder"),
                        NotificationManager.IMPORTANCE_DEFAULT);
                    nm.createNotificationChannel(ch);
                }
            } catch (Throwable ignored) {}
        }
    }
}
