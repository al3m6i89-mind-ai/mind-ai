package com.nooralmehrab.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/** Full-text search across the Quran. */
public final class QuranSearch {
    private QuranSearch() {}

    private static final int MAX_RESULTS = 50;

    public static void open(final MainActivity a) {
        Features.withQuran(a, new Features.Then() {
            @Override public void run() { show(a); }
        });
    }

    private static void show(final MainActivity a) {
        p1.c p = Ui.pal(a);
        int bg = p.a ? 0xFF1A1A2E : 0xFFF5F5F5;
        int cardBg = p.a ? 0xFF252540 : 0xFFFFFFFF;
        int textColor = p.a ? 0xFFEEEEEE : 0xFF1A1A1A;
        int subColor = p.a ? 0xFF9999BB : 0xFF666666;
        int accent = p.b;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        // Search field
        EditText et = new EditText(a);
        et.setHint(Ui.s("ابحث في القرآن…", "Search the Quran…"));
        et.setTextColor(textColor);
        et.setHintTextColor(subColor);
        et.setTextSize(16f);
        et.setSingleLine(true);
        et.setTextDirection(View.TEXT_DIRECTION_LOCALE);
        int ep = dp(a, 14);
        et.setPadding(ep, ep, ep, ep);
        et.setBackgroundColor(cardBg);
        root.addView(et, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Separator
        View sep = new View(a);
        sep.setBackgroundColor(p.a ? 0x33FFFFFF : 0x22000000);
        root.addView(sep, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 1));

        // Results area
        final ScrollView scroll = new ScrollView(a);
        final LinearLayout results = new LinearLayout(a);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setBackgroundColor(bg);
        int rp = dp(a, 10);
        results.setPadding(rp, rp, rp, rp);
        scroll.addView(results);
        LinearLayout.LayoutParams sclp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, sclp);

        // Initial hint
        TextView hint = new TextView(a);
        hint.setText(Ui.s("اكتب كلمة للبحث عنها في القرآن الكريم", "Type a word to search in the Quran"));
        hint.setTextColor(subColor);
        hint.setTextSize(14f);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(a, 16), dp(a, 32), dp(a, 16), dp(a, 16));
        results.addView(hint);

        final Handler h = new Handler(Looper.getMainLooper());
        final Runnable[] searchRunnable = {null};

        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int af) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (searchRunnable[0] != null) h.removeCallbacks(searchRunnable[0]);
                final String q = s.toString().trim();
                searchRunnable[0] = new Runnable() {
                    @Override public void run() {
                        doSearch(a, q, results, p, textColor, subColor, accent, cardBg);
                    }
                };
                h.postDelayed(searchRunnable[0], 300);
            }
        });

        AlertDialog d = new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("بحث في القرآن", "Search the Quran"))
            .setView(root)
            .setNegativeButton(Ui.s("إغلاق", "Close"), null)
            .create();
        d.show();

        et.requestFocus();
        try {
            InputMethodManager imm = (InputMethodManager) a.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
        } catch (Throwable ignored) {}
    }

    private static void doSearch(final MainActivity a, String query, LinearLayout results,
            p1.c p, int textColor, int subColor, int accent, int cardBg) {
        results.removeAllViews();
        if (query.length() < 2) {
            TextView h = new TextView(a);
            h.setText(Ui.s("اكتب كلمتين على الأقل", "Type at least 2 characters"));
            h.setTextColor(subColor);
            h.setTextSize(13f);
            h.setGravity(Gravity.CENTER);
            h.setPadding(dp(a, 16), dp(a, 24), dp(a, 16), dp(a, 16));
            results.addView(h);
            return;
        }
        String lq = query.toLowerCase();
        boolean arabic = isArabic(query);
        ArrayList<int[]> found = new ArrayList<>();
        outer:
        for (int s = 1; s <= 114; s++) {
            int cnt = Quran.count(s);
            for (int v = 1; v <= cnt; v++) {
                String ayah = Quran.ayat[s - 1][v - 1];
                if (arabic ? ayah.contains(query) : ayah.toLowerCase().contains(lq)) {
                    found.add(new int[]{s, v});
                    if (found.size() >= MAX_RESULTS) break outer;
                }
            }
        }

        if (found.isEmpty()) {
            TextView no = new TextView(a);
            no.setText(Ui.s("لا توجد نتائج", "No results found"));
            no.setTextColor(subColor);
            no.setTextSize(14f);
            no.setGravity(Gravity.CENTER);
            no.setPadding(dp(a, 16), dp(a, 32), dp(a, 16), dp(a, 16));
            results.addView(no);
            return;
        }

        TextView counter = new TextView(a);
        String cnt = found.size() == MAX_RESULTS
            ? Ui.s(MAX_RESULTS + "+ نتيجة", MAX_RESULTS + "+ results")
            : Ui.s(found.size() + " نتيجة", found.size() + " results");
        counter.setText(cnt);
        counter.setTextColor(subColor);
        counter.setTextSize(12f);
        counter.setGravity(Gravity.CENTER);
        counter.setPadding(0, dp(a, 4), 0, dp(a, 12));
        results.addView(counter);

        for (final int[] sv : found) {
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(cardBg);
            int cp = dp(a, 12);
            card.setPadding(cp, cp, cp, cp);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(a, 8));
            card.setLayoutParams(lp);
            try {
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setColor(cardBg);
                gd.setCornerRadius(dp(a, 10));
                card.setBackground(gd);
            } catch (Throwable ignored) {}

            // Surah:Verse label
            String loc = (L10n.en() ? "Surah " + Quran.nameEn[sv[0]-1] : "سورة " + Quran.nameAr[sv[0]-1])
                + " : " + Ui.n(sv[1]);
            TextView locView = new TextView(a);
            locView.setText(loc);
            locView.setTextColor(accent);
            locView.setTextSize(12f);
            locView.setTypeface(Typeface.DEFAULT_BOLD);
            card.addView(locView);

            // Ayah text (truncated if long)
            String ayah = Quran.ayat[sv[0]-1][sv[1]-1];
            if (ayah.length() > 180) ayah = ayah.substring(0, 177) + "…";
            TextView ayahView = Features.quranText(a, ayah, 16f);
            card.addView(ayahView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            card.setClickable(true);
            final int surah = sv[0];
            card.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { Features.openSurah(a, surah); }
            });
            results.addView(card);
        }
    }

    private static boolean isArabic(String s) {
        for (char c : s.toCharArray()) if (c >= 0x0600 && c <= 0x06FF) return true;
        return false;
    }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
