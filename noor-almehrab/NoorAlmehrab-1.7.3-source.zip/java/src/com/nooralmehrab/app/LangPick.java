package com.nooralmehrab.app;

/** Called when a language chip is tapped. */
public final class LangPick implements B1.l {
    private final MainActivity act;

    public LangPick(MainActivity act) { this.act = act; }

    @Override
    public Object h(Object o) {
        boolean en = ((Enum) o).ordinal() == 1;
        if (en != L10n.en()) L10n.switchTo(act, en);
        return q1.g.a;
    }
}
