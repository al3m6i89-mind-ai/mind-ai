set -e
W=/tmp/claude-0/w; cd $W/java
rm -rf out stubout tmpapk x.apk new.dex smaliout && mkdir -p out stubout tmpapk
javac -nowarn -encoding UTF-8 --release 8 -cp ../android-all-14-robolectric-10818077.jar -d stubout $(find stubs -name '*.java') 2>&1 | grep -v 'JAVA_TOOL\|^Note' || true
javac -Xlint:none -encoding UTF-8 --release 8 -cp ../android-all-14-robolectric-10818077.jar:stubout -d out $(find src -name '*.java') 2>&1 | grep -v 'JAVA_TOOL\|^Note\|warning: \[options\]\|^1 warning' || true
test -f out/com/nooralmehrab/app/L10n.class
java -cp ../dalvik-dx-14.0.0_r21.jar com.android.dx.command.Main --dex --min-sdk-version=26 --output=new.dex out
cp new.dex tmpapk/classes.dex && (cd tmpapk && zip -q ../x.apk classes.dex)
java -jar ../apktool.jar d -r -f x.apk -o smaliout >/dev/null 2>&1
echo compiled
