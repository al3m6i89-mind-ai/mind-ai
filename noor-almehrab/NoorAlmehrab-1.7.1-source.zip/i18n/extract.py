import re,json,glob
def dec(s): return s.encode('latin1').decode('unicode_escape') if '\\' in s else s
L=open('java/src/com/nooralmehrab/app/L10n.java',encoding='utf-8').read()
vals=[]
for m in re.finditer(r'm\.put\("((?:[^"\\]|\\.)*)", "((?:[^"\\]|\\.)*)"\);',L):
    v=m.group(2).encode('ascii').decode('unicode_escape').encode('utf-16','surrogatepass').decode('utf-16')
    vals.append(v)
lit=r'"((?:[^"\\]|\\.)*)"'
uis=[]; odd=[]
for f in glob.glob('java/src/com/nooralmehrab/app/*.java'):
    if f.endswith('L10n.java'): continue
    src=open(f,encoding='utf-8').read()
    for m in re.finditer(r'Ui\.s\(',src):
        # find matching paren
        i=m.end(); depth=1; j=i; ins=False
        while depth:
            c=src[j]
            if ins:
                if c=='\\': j+=1
                elif c=='"': ins=False
            else:
                if c=='"': ins=True
                elif c=='(': depth+=1
                elif c==')': depth-=1
                elif c==',' and depth==1: comma=j
            j+=1
        en=src[comma+1:j-1].strip()
        if re.fullmatch(lit,en): uis.append(json.loads('"'+re.fullmatch(lit,en).group(1)+'"'))
        else: odd.append((f.split('/')[-1],en))
allv=[]
for v in vals+uis:
    if v.strip() and v not in allv: allv.append(v)
json.dump(allv,open('i18n/en.json','w'),ensure_ascii=False,indent=0)
print(len(vals),len(uis),len(allv))
for o in odd: print('ODD',o)
# extra: Ui.f formats, L10n.x literals, arrays
extra=[]
for f in glob.glob('java/src/com/nooralmehrab/app/*.java'):
    src=open(f,encoding='utf-8').read()
    for m in re.finditer(r'Ui\.f\('+lit+r', '+lit,src): extra.append(json.loads('"'+m.group(2)+'"'))
    for m in re.finditer(r'L10n\.x\('+lit,src): extra.append(json.loads('"'+m.group(1)+'"'))
    for m in re.finditer(r'xa\(new String\[\]\{([^}]*)\}',src):
        extra+= [json.loads('"'+x+'"') for x in re.findall(lit,m.group(1))]
    for name in ['HIJRI_MONTHS_EN','NAMES_EN']:
        m=re.search(name+r' = \{([^}]*)\}',src)
        if m: extra+= [json.loads('"'+x+'"') for x in re.findall(lit,m.group(1))]
    m=re.search(r'SUNNAH = \{(.*?)\n    \};',src,re.S)
    if m:
        for row in re.findall(r'\{((?:"(?:[^"\\]|\\.)*",?\s*){6})\}',m.group(1)):
            xs=[json.loads('"'+x+'"') for x in re.findall(lit,row)]
            extra+= [xs[3],xs[4],xs[5]]
extra+=[" PM"," AM"]
for v in extra:
    if v.strip() and v not in allv: allv.append(v)
json.dump(allv,open('i18n/en.json','w'),ensure_ascii=False,indent=0)
print('total',len(allv))
