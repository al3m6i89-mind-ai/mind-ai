package com.nooralmehrab.app;

/** Filled in by the build script. */
final class BuildInfo {
    private BuildInfo() {}

    static final String VERSION = "1.7.1";
    static final String BUILT = "2026-10-28 16:10";
    static final String UPDATE_URL = "https://www.dropbox.com/scl/fi/colx0gpqiwmaqjfabbcyi/update.json?rlkey=s4o2uy8udnmnp72odv2n37m1l&st=wdbpf1t3&dl=0";
}
