package com.nooralmehrab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/**
 * Checks update.json on every launch. A newer version can be postponed for one day after it was
 * published; after that the update is required and the app stays blocked until it is installed.
 * The APK is downloaded inside the app and handed to the system installer.
 */
public final class Updater {
    private Updater() {}

    static final long GRACE_MS = 24L * 60 * 60 * 1000;
    static final long RECHECK_MS = 30L * 60 * 1000;
    /** How often the reminder dialog and the notification are shown for an optional update. */
    static final long REMIND_MS = 4L * 60 * 60 * 1000;
    static final String CH = "noor_update";

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static volatile boolean busy;
    private static volatile long lastCheck;
    private static volatile JSONObject latest;
    private static AlertDialog shown;

    static long versionCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Throwable t) {
            return 0;
        }
    }

    static String versionName(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return BuildInfo.VERSION;
        }
    }

    /** MainActivity.onResume */
    public static void onResume(Activity a) {
        if (!(a instanceof MainActivity)) return;
        final MainActivity m = (MainActivity) a;
        JSONObject j = latest;
        if (j != null && System.currentTimeMillis() - lastCheck < RECHECK_MS) {
            decide(m, j, false);
            return;
        }
        check(m, false);
    }

    public static void check(final MainActivity a, final boolean manual) {
        if (BuildInfo.UPDATE_URL.length() == 0) {
            if (manual) Ui.toast(a, Ui.s("أنت تستخدم آخر إصدار ✓", "You're on the latest version ✓"));
            return;
        }
        if (busy) return;
        busy = true;
        if (manual) Ui.toast(a, Ui.s("جاري البحث عن تحديثات…", "Checking for updates…"));
        new Thread(new Runnable() {
            @Override public void run() {
                JSONObject j = null;
                try {
                    j = new JSONObject(fetch(direct(BuildInfo.UPDATE_URL)));
                    latest = j;
                    lastCheck = System.currentTimeMillis();
                } catch (Throwable ignored) {
                }
                final JSONObject res = j;
                ui.post(new Runnable() {
                    @Override public void run() {
                        busy = false;
                        if (a.isFinishing()) return;
                        if (res == null) {
                            if (manual) Ui.toast(a, Ui.s("تعذّر الاتصال بخادم التحديثات، تأكد من الإنترنت.", "Couldn't reach the update server. Check your internet connection."));
                            return;
                        }
                        decide(a, res, manual);
                    }
                });
            }
        }).start();
    }

    /** Dropbox share links ("...?dl=0") become direct downloads ("dl=1"). */
    static String direct(String u) {
        if (u == null || !u.contains("dropbox.com")) return u;
        if (u.contains("dl=0")) return u.replace("dl=0", "dl=1");
        if (u.contains("dl=1") || u.contains("raw=1")) return u;
        return u + (u.contains("?") ? "&" : "?") + "dl=1";
    }

    private static String fetch(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setUseCaches(false);
        c.setRequestProperty("Cache-Control", "no-cache");
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private static boolean forced(JSONObject j) {
        if (j.optBoolean("forceNow", false)) return true;
        long at = j.optLong("releasedAt", 0);
        return at > 0 && System.currentTimeMillis() - at >= GRACE_MS;
    }

    private static void decide(MainActivity a, JSONObject j, boolean manual) {
        long remote = j.optLong("versionCode", 0);
        if (remote <= versionCode(a)) {
            if (manual) Ui.toast(a, Ui.s("أنت تستخدم آخر إصدار ✓", "You're on the latest version ✓"));
            return;
        }
        boolean force = forced(j);
        // Post a notification in the status bar too (throttled like the dialog).
        notifyUpdate(a, j, force);
        if (!force && !manual) {
            // Optional updates are offered again every few hours.
            SharedPreferences p = Features.prefs(a);
            String key = "upd_asked_" + remote;
            if (System.currentTimeMillis() - p.getLong(key, 0) < REMIND_MS) return;
            p.edit().putLong(key, System.currentTimeMillis()).apply();
        }
        show(a, j, force);
    }

    /** A quick background check from a prayer-time alarm: posts a notification if an update is due. */
    public static void background(final Context c) {
        if (c == null || BuildInfo.UPDATE_URL.length() == 0) return;
        final Context app = c.getApplicationContext();
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    JSONObject j = new JSONObject(fetch(direct(BuildInfo.UPDATE_URL)));
                    if (j.optLong("versionCode", 0) > versionCode(app)) {
                        notifyUpdate(app, j, forced(j));
                    }
                } catch (Throwable ignored) {
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    /** Status-bar notification that a new version is available; tapping it opens the app. */
    static void notifyUpdate(Context c, JSONObject j, boolean force) {
        try {
            long remote = j.optLong("versionCode", 0);
            SharedPreferences p = Features.prefs(c);
            String key = "upd_notif_" + remote;
            if (!force && System.currentTimeMillis() - p.getLong(key, 0) < REMIND_MS) return;
            p.edit().putLong(key, System.currentTimeMillis()).apply();

            android.app.NotificationManager nm =
                (android.app.NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel ch = new android.app.NotificationChannel(
                    CH, Ui.s("تحديثات التطبيق", "App updates"),
                    android.app.NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            int icon = c.getResources().getIdentifier("ic_notification", "drawable", c.getPackageName());
            if (icon == 0) icon = android.R.drawable.stat_sys_download_done;

            String name = j.optString("versionName", "");
            String notes = L10n.notes(j);
            String title = (force
                ? Ui.s("تحديث إجباري متوفر ", "Required update available ")
                : Ui.s("تحديث جديد متوفر ", "New update available ")) + name;
            String text = notes.length() > 0 ? notes.replace("\n", " · ")
                : Ui.s("افتح التطبيق لتثبيت آخر إصدار.", "Open the app to install the latest version.");

            Intent open = new Intent(c, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? 0x04000000 /* FLAG_IMMUTABLE */ : 0);
            PendingIntent pi = PendingIntent.getActivity(c, 7001, open, flags);

            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CH) : new Notification.Builder(c);
            b.setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi);
            b.setOngoing(force);
            nm.notify(7001, b.build());
        } catch (Throwable ignored) {
        }
    }

    private static void show(final MainActivity a, final JSONObject j, final boolean force) {
        if (shown != null && shown.isShowing()) {
            if (!force || !shown.isShowing()) return;
            shown.dismiss();
        }
        p1.c p = Ui.pal(a);
        String name = j.optString("versionName", "");
        String notes = L10n.notes(j);
        String msg = (force
                ? Ui.s("نوفّر لك إصدارًا محسّنًا من نور المحراب. نرجو التحديث لمواصلة استخدام التطبيق.", "An improved version of Noor Al-Mehrab is ready. Please update to keep using the app.")
                : Ui.s("يسعدنا أن نوفّر لك إصدارًا جديدًا من نور المحراب، حرصنا فيه على تحسين تجربتك. ننصحك بالتحديث الآن.", "We're pleased to bring you a new version of Noor Al-Mehrab with improvements for you. We recommend updating now."))
                + (notes.length() > 0 ? "\n\n" + notes : "");
        AlertDialog.Builder b = new AlertDialog.Builder(a, p.a ? 4 : 5)
                .setTitle(Ui.s("تحديث جديد ", "New update ") + name)
                .setMessage(msg)
                .setCancelable(!force)
                .setPositiveButton(Ui.s("تحديث الآن", "Update now"), null);
        if (!force) b.setNegativeButton(Ui.s("لاحقاً", "Later"), null);
        final AlertDialog d = b.create();
        d.setCanceledOnTouchOutside(!force);
        if (force) {
            d.setOnKeyListener(new DialogInterface.OnKeyListener() {
                @Override public boolean onKey(DialogInterface di, int code, android.view.KeyEvent e) {
                    if (code == android.view.KeyEvent.KEYCODE_BACK && e.getAction() == android.view.KeyEvent.ACTION_UP) {
                        a.finish();
                        return true;
                    }
                    return false;
                }
            });
        }
        d.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface di) {
                if (d.getWindow() != null) L10n.dir(d.getWindow().getDecorView(), View.LAYOUT_DIRECTION_RTL);
                d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (!force) d.dismiss();
                        download(a, j, force);
                    }
                });
            }
        });
        shown = d;
        d.show();
    }

    private static void download(final MainActivity a, final JSONObject j, final boolean force) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Ui.toast(a, Ui.s("فعّل «السماح من هذا المصدر» لنور المحراب ثم ارجع للتطبيق.", "Turn on “Allow from this source” for Noor Al-Mehrab, then come back."));
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
            } catch (Throwable ignored) {
            }
            return;
        }
        final long code = j.optLong("versionCode", 0);
        final String url = direct(j.optString("apkUrl", ""));
        final File dir = new File(a.getCacheDir(), "update");
        dir.mkdirs();
        final File apk = new File(dir, "noor-" + code + ".apk");

        p1.c p = Ui.pal(a);
        LinearLayout box = Ui.vbox(a);
        int pad = Ui.dp(a, 22);
        box.setPadding(pad, pad, pad, pad);
        final TextView label = Ui.text(a, Ui.s("جاري تحميل التحديث… ٠٪", "Downloading update… 0%"), 15, p.i, false);
        box.addView(label);
        final ProgressBar bar = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(p.g));
        box.addView(bar, Ui.full(a, 14));
        final AlertDialog prog = new AlertDialog.Builder(a, p.a ? 4 : 5).setView(box).setCancelable(false).create();
        prog.show();
        if (prog.getWindow() != null) L10n.dir(prog.getWindow().getDecorView(), View.LAYOUT_DIRECTION_RTL);

        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                try {
                    if (!apk.exists() || apk.length() == 0) {
                        File part = new File(dir, "noor-" + code + ".part");
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                        c.setInstanceFollowRedirects(true);
                        if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
                        long total = c.getContentLengthLong();
                        InputStream in = c.getInputStream();
                        OutputStream out = new FileOutputStream(part);
                        byte[] buf = new byte[65536];
                        long got = 0;
                        int n, last = -1;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            got += n;
                            if (total > 0) {
                                final int pct = (int) (got * 100 / total);
                                if (pct != last) {
                                    last = pct;
                                    ui.post(new Runnable() {
                                        @Override public void run() {
                                            bar.setProgress(pct);
                                            label.setText(Ui.s("جاري تحميل التحديث… ", "Downloading update… ") + Ui.n(pct) + Ui.s("٪", "%"));
                                        }
                                    });
                                }
                            }
                        }
                        out.close();
                        in.close();
                        c.disconnect();
                        if (!part.renameTo(apk)) throw new Exception("rename");
                    }
                    install(a, apk);
                    ok = true;
                } catch (Throwable t) {
                    apk.delete();
                }
                final boolean fine = ok;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { prog.dismiss(); } catch (Throwable ignored) {}
                        if (!fine) {
                            Ui.toast(a, Ui.s("تعذّر تحميل التحديث، حاول مرة أخرى.", "Couldn't download the update. Please try again."));
                            if (force && !a.isFinishing()) show(a, j, true);
                        }
                    }
                });
            }
        }).start();
    }

    private static void install(Context c, File apk) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(c.getPackageName());
        if (Build.VERSION.SDK_INT >= 31) sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        int id = pi.createSession(sp);
        PackageInstaller.Session s = pi.openSession(id);
        try {
            OutputStream out = s.openWrite("base.apk", 0, apk.length());
            InputStream in = new FileInputStream(apk);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            s.fsync(out);
            out.close();
            Intent i = new Intent(c, InstallReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? 0x02000000 /* FLAG_MUTABLE */ : 0);
            PendingIntent pi2 = PendingIntent.getBroadcast(c, id, i, flags);
            s.commit(pi2.getIntentSender());
        } finally {
            s.close();
        }
    }
}
