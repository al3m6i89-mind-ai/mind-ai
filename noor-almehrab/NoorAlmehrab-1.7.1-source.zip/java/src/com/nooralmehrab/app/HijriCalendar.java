package com.nooralmehrab.app;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;

/** Hijri (Islamic lunar) calendar converter and Islamic events display. */
public final class HijriCalendar {
    private HijriCalendar() {}

    private static final String[] HIJRI_MONTHS_AR = {
        "مُحَرَّم", "صَفَر", "رَبِيع الأَوَّل", "رَبِيع الثَّانِي",
        "جُمَادَى الأُولَى", "جُمَادَى الثَّانِيَة", "رَجَب", "شَعْبَان",
        "رَمَضَان", "شَوَّال", "ذُو القَعْدَة", "ذُو الحِجَّة"
    };
    private static final String[] HIJRI_MONTHS_EN = {
        "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
        "Jumada al-Ula", "Jumada al-Thaniyah", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    };

    /** { year, month (1-12), day } */
    public static int[] toHijri(int gy, int gm, int gd) {
        // Gregorian to Julian Day Number
        long a = (14 - gm) / 12;
        long y = gy + 4800 - a;
        long m = gm + 12 * a - 3;
        long jdn = gd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        // Julian Day to Hijri (Tabular Islamic calendar)
        long l = jdn - 1948440 + 10632;
        long n = (l - 1) / 10631;
        l = l - 10631 * n + 354;
        long j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238);
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29;
        long hYear = 30 * n + j - 30;
        long hMonth = (59 * l - 1) / 1771;
        long hDay = l - (29 * hMonth + hMonth / 2);
        hMonth++;
        return new int[]{(int) hYear, (int) hMonth, (int) hDay};
    }

    public static void open(final MainActivity a) {
        p1.c p = Ui.pal(a);
        int bg = p.b;
        int cardBg = p.d;
        int textColor = p.i;
        int subColor = p.j;
        int accent = p.g;

        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(a, 14);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        // Today's date card
        Calendar cal = Calendar.getInstance();
        int gy = cal.get(Calendar.YEAR);
        int gm = cal.get(Calendar.MONTH) + 1;
        int gd = cal.get(Calendar.DAY_OF_MONTH);
        int[] h = toHijri(gy, gm, gd);

        LinearLayout todayCard = makeCard(a, cardBg);
        TextView dateTitle = new TextView(a);
        dateTitle.setText(Ui.s("تاريخ اليوم", "Today's Date"));
        dateTitle.setTextColor(subColor);
        dateTitle.setTextSize(12f);
        todayCard.addView(dateTitle);

        TextView hijriDate = new TextView(a);
        String hd = Ui.n(h[2]) + " " + (L10n.latin() ? L10n.x(HIJRI_MONTHS_EN[h[1]-1]) : HIJRI_MONTHS_AR[h[1]-1]) + " " + Ui.n(h[0]) + Ui.s(" هـ", " AH");
        hijriDate.setText(hd);
        hijriDate.setTextSize(24f);
        hijriDate.setTextColor(accent);
        hijriDate.setGravity(Gravity.CENTER);
        todayCard.addView(hijriDate, pad(a, 8, 0));

        TextView gregDate = new TextView(a);
        gregDate.setText(gd + "/" + gm + "/" + gy + Ui.s(" م", ""));
        gregDate.setTextSize(14f);
        gregDate.setTextColor(subColor);
        gregDate.setGravity(Gravity.CENTER);
        todayCard.addView(gregDate, pad(a, 4, 0));

        root.addView(todayCard, cardLp(a));

        // Islamic events this year
        int hYear = h[0];
        root.addView(sectionTitle(a, Ui.f("المناسبات الإسلامية %s هـ", "Islamic Events %s AH", Ui.n(hYear)), accent), pad(a, 20, 0));

        String[][] events = {
            {"1", "1",  Ui.s("رأس السنة الهجرية", "Islamic New Year")},
            {"1", "10", Ui.s("عاشوراء", "Day of Ashura")},
            {"3", "12", Ui.s("المولد النبوي الشريف", "Prophet's Birthday (Mawlid)")},
            {"7", "27", Ui.s("ليلة المعراج", "Night of Isra' and Mi'raj")},
            {"8", "15", Ui.s("ليلة النصف من شعبان", "Mid-Sha'ban Night")},
            {"9", "1",  Ui.s("أول رمضان", "Start of Ramadan")},
            {"9", "27", Ui.s("ليلة القدر (المرتقبة)", "Laylat al-Qadr (expected)")},
            {"10", "1", Ui.s("عيد الفطر المبارك", "Eid al-Fitr")},
            {"12", "8", Ui.s("يوم التروية", "Day of Tarwiyah")},
            {"12", "9", Ui.s("يوم عرفة", "Day of Arafah")},
            {"12", "10", Ui.s("عيد الأضحى المبارك", "Eid al-Adha")},
            {"12", "11", Ui.s("أيام التشريق الأولى", "First days of Tashreeq")},
            {"12", "18", Ui.s("غدير خم", "")},
        };

        for (String[] ev : events) {
            if (ev[2].isEmpty()) continue;
            int evMonth = Integer.parseInt(ev[0]);
            int evDay   = Integer.parseInt(ev[1]);
            // Convert this Hijri date back to Gregorian for display
            long jdn = hijriToJdn(hYear, evMonth, evDay);
            int[] greg = jdnToGregorian(jdn);
            boolean today = greg[0] == gy && greg[1] == gm && greg[2] == gd;
            boolean past  = jdn < hijriToJdn(h[0], h[1], h[2]);

            LinearLayout row = makeCard(a, today ? p.e : cardBg);
            LinearLayout inner = new LinearLayout(a);
            inner.setOrientation(LinearLayout.HORIZONTAL);
            inner.setGravity(android.view.Gravity.CENTER_VERTICAL);
            inner.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // Month badge
            TextView badge = new TextView(a);
            String mName = L10n.latin() ? L10n.x(HIJRI_MONTHS_EN[evMonth-1]).split(" ")[0] : HIJRI_MONTHS_AR[evMonth-1].split(" ")[0];
            badge.setText(Ui.n(evDay) + "\n" + mName);
            badge.setTextSize(11f);
            badge.setGravity(Gravity.CENTER);
            badge.setTextColor(today ? accent : subColor);
            badge.setPadding(dp(a, 8), dp(a, 4), dp(a, 12), dp(a, 4));
            inner.addView(badge);

            LinearLayout col = new LinearLayout(a);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView name = new TextView(a);
            name.setText(ev[2]);
            name.setTextSize(15f);
            name.setTextColor(past && !today ? subColor : textColor);
            col.addView(name);

            TextView gDate = new TextView(a);
            gDate.setText(greg[2] + "/" + greg[1] + "/" + greg[0]);
            gDate.setTextSize(11f);
            gDate.setTextColor(subColor);
            col.addView(gDate);

            inner.addView(col);
            if (today) {
                TextView now = new TextView(a);
                now.setText(Ui.s("اليوم", "Today"));
                now.setTextSize(11f);
                now.setTextColor(accent);
                now.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                inner.addView(now);
            }
            row.addView(inner);
            root.addView(row, cardLp(a));
        }

        new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("التقويم الهجري", "Hijri Calendar"))
            .setView(scroll)
            .setNegativeButton(Ui.s("إغلاق", "Close"), null)
            .show();
    }

    private static long hijriToJdn(int hy, int hm, int hd) {
        return (long)(11 * hy + 3) / 30 + 354L * hy + 30 * hm
            - (long)(hm - 1) / 2 + hd + 1948440 - 385;
    }

    private static int[] jdnToGregorian(long jdn) {
        long l = jdn + 68569;
        long n = 4 * l / 146097;
        l = l - (146097 * n + 3) / 4;
        long i = 4000 * (l + 1) / 1461001;
        l = l - 1461 * i / 4 + 31;
        long j = 80 * l / 2447;
        int gd = (int)(l - 2447 * j / 80);
        l = j / 11;
        int gm = (int)(j + 2 - 12 * l);
        int gy = (int)(100 * (n - 49) + i + l);
        return new int[]{gy, gm, gd};
    }

    private static LinearLayout makeCard(Context c, int color) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        int cp = dp(c, 14);
        card.setPadding(cp, cp, cp, cp);
        try {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(color);
            gd.setCornerRadius(dp(c, 12));
            card.setBackground(gd);
        } catch (Throwable ignored) {}
        return card;
    }

    private static TextView sectionTitle(Context c, String text, int color) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(15f);
        tv.setTextColor(color);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private static LinearLayout.LayoutParams cardLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, 8), 0, 0);
        return lp;
    }

    private static LinearLayout.LayoutParams pad(Context c, int top, int bot) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, top), 0, dp(c, bot));
        return lp;
    }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
