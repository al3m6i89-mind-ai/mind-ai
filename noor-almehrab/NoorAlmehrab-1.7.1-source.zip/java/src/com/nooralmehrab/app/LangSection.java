package com.nooralmehrab.app;

import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Builds the language card body in Settings, reusing the app's segmented control (same look as Appearance). */
public final class LangSection implements B1.l {
    static final String[] NAMES = {"العربية", "English", "Türkçe", "اردو"};

    private final MainActivity act;

    public LangSection(MainActivity act) { this.act = act; }

    @Override
    public Object h(Object o) {
        LinearLayout card = (LinearLayout) o;
        // The control only needs one distinct enum constant per option; its ordinal is the language.
        TimeUnit[] v = TimeUnit.values();
        List<q1.c> opts = new ArrayList<>();
        for (int i = 0; i < NAMES.length; i++) opts.add(new q1.c(v[i], NAMES[i]));
        LinearLayout row = act.a(opts, v[L10n.lang()], new LangPick(act));
        A0.a.a(card, (View) row, A0.a.A(0, 0, 0f, 0, 15));
        return q1.g.a;
    }
}
