package com.nooralmehrab.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Pre-prayer reminder: schedules a notification N minutes before each prayer.
 * The minute count is stored in SharedPreferences (key "pre_prayer_min", default 15).
 * Scheduling is triggered from AlarmReceiver when an ADHAN fires — at that moment
 * we know the current prayer's time and compute the next prayer offset using
 * the same NOAA approach as SunTimes, plus a basic prayer times formula.
 */
public final class PrayerAlerts {
    private PrayerAlerts() {}

    static final String CHANNEL  = "noor_prayer_alert";
    static final int    BASE_ID  = 9001;
    private static final String PREF    = "prayer_alerts";
    private static final String KEY_MIN = "pre_prayer_min";
    private static final String ACTION  = "com.nooralmehrab.app.PRE_PRAYER";

    /** Called from AlarmReceiver when action == ACTION. */
    public static void onAlarm(Context ctx, Intent intent) {
        if (!ACTION.equals(intent != null ? intent.getAction() : null)) return;
        String name = intent.getStringExtra("prayer");
        if (name == null) return;
        int min = getMinutes(ctx);
        String title = Ui.s("تذكير بالصلاة", "Prayer Reminder");
        String body  = Ui.f("تبقّى %2$s دقيقة على %1$s", "%1$s in %2$s minutes", name, min);
        AdhkarNotify.showNotification(ctx, BASE_ID + prayerIndex(name), title, body);
    }

    /** Schedule a pre-prayer alert 'minutes' before the given UTC millisecond time. */
    public static void schedule(Context ctx, String prayerName, long atMs) {
        int min = getMinutes(ctx);
        if (min <= 0) return;
        long triggerAt = atMs - (long) min * 60 * 1000;
        if (triggerAt <= System.currentTimeMillis()) return;
        try {
            createChannel(ctx);
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(ACTION);
            i.setClassName(ctx, "com.nooralmehrab.app.notify.AlarmReceiver");
            i.putExtra("prayer", prayerName);
            int reqId = BASE_ID + prayerIndex(prayerName);
            PendingIntent pi = PendingIntent.getBroadcast(ctx, reqId, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (Throwable ignored) {}
    }

    public static int getMinutes(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(KEY_MIN, 15);
    }

    public static void setMinutes(Context ctx, int min) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY_MIN, min).apply();
    }

    private static int prayerIndex(String name) {
        if (name == null) return 0;
        switch (name.toLowerCase()) {
            case "fajr":    case "الفجر":   return 0;
            case "dhuhr":   case "الظهر":   return 1;
            case "asr":     case "العصر":   return 2;
            case "maghrib": case "المغرب": return 3;
            case "isha":    case "العشاء": return 4;
            default: return 0;
        }
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL,
                        Ui.s("تذكير قبل الصلاة", "Pre-Prayer Reminder"),
                        NotificationManager.IMPORTANCE_HIGH);
                    nm.createNotificationChannel(ch);
                }
            } catch (Throwable ignored) {}
        }
    }

    /** Settings UI: choose how many minutes before the prayer to be alerted. */
    public static void openSettings(final MainActivity a) {
        p1.c p = Ui.pal(a);
        final int[] opts = {5, 10, 15, 20, 30};
        int cur = getMinutes(a);
        String[] labels = new String[opts.length + 1];
        labels[0] = Ui.s("إيقاف التنبيه", "Disabled");
        int sel = 0;
        for (int i = 0; i < opts.length; i++) {
            labels[i + 1] = Ui.f("%s دقيقة قبل الصلاة", "%s minutes before prayer", opts[i]);
            if (opts[i] == cur) sel = i + 1;
        }
        if (cur <= 0) sel = 0;
        new android.app.AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("تنبيه قبل الصلاة", "Pre-Prayer Alert"))
            .setSingleChoiceItems(labels, sel, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int which) {
                    setMinutes(a, which == 0 ? 0 : opts[which - 1]);
                    d.dismiss();
                    Ui.toast(a, which == 0
                        ? Ui.s("تم إيقاف التنبيه", "Alert disabled")
                        : Ui.f("سيصلك تنبيه قبل الصلاة بـ %s دقيقة", "Alert set for %s min before prayer", opts[which-1]));
                }
            })
            .setNegativeButton(Ui.s("إلغاء", "Cancel"), null)
            .show();
    }
}
