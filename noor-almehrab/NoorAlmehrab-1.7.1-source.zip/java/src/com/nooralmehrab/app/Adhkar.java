package com.nooralmehrab.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Adhkar section: morning, evening, post-prayer, salah guide. */
public final class Adhkar {
    private Adhkar() {}

    /** Shows the adhkar category picker dialog. */
    public static void open(final MainActivity a) {
        p1.c p = Ui.pal(a);
        String[] cats = L10n.en()
            ? L10n.xa(new String[]{"☀️  Morning Adhkar", "🌙  Evening Adhkar", "🕌  After Prayer", "📿  Prayer Guide"})
            : new String[]{"☀️  أذكار الصباح", "🌙  أذكار المساء", "🕌  أذكار بعد الصلاة", "📿  أدعية الصلاة"};
        new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("الأذكار", "Adhkar"))
            .setItems(cats, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface d, int which) {
                    String[][] data;
                    String title;
                    switch (which) {
                        case 0: data = AdhkarData.MORNING;  title = Ui.s("أذكار الصباح","Morning Adhkar"); break;
                        case 1: data = AdhkarData.EVENING;  title = Ui.s("أذكار المساء","Evening Adhkar"); break;
                        case 2: data = AdhkarData.AFTER_PRAYER; title = Ui.s("أذكار بعد الصلاة","After Prayer"); break;
                        default: data = AdhkarData.SALAH;   title = Ui.s("أدعية الصلاة","Prayer Guide"); break;
                    }
                    showList(a, title, data);
                }
            })
            .setNegativeButton(Ui.s("إغلاق","Close"), null)
            .show();
    }

    private static void showList(final MainActivity a, String title, final String[][] data) {
        p1.c p = Ui.pal(a);
        int bg = p.b;
        int cardBg = p.d;
        int textColor = p.i;
        int subColor = p.j;
        int accentColor = p.g;

        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(a, 12);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        for (int i = 0; i < data.length; i++) {
            final String[] item = data[i];
            final int idx = i;
            // Card container
            LinearLayout card = new LinearLayout(a);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(cardBg);
            int cp = dp(a, 16);
            card.setPadding(cp, cp, cp, cp);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, dp(a, 10));
            card.setLayoutParams(lp);
            // Rounded corners via background
            try {
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setColor(cardBg);
                gd.setCornerRadius(dp(a, 12));
                card.setBackground(gd);
            } catch (Throwable ignored) {}

            // Title row
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // Counter badge
            TextView badge = new TextView(a);
            badge.setText("× " + item[2]);
            badge.setTextColor(accentColor);
            badge.setTextSize(12f);
            badge.setPadding(dp(a, 8), dp(a, 4), dp(a, 8), dp(a, 4));
            try {
                android.graphics.drawable.GradientDrawable bd = new android.graphics.drawable.GradientDrawable();
                bd.setColor(p.a ? 0x33FFFFFF : 0x11000000);
                bd.setCornerRadius(dp(a, 8));
                badge.setBackground(bd);
            } catch (Throwable ignored) {}
            LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            badgeLp.gravity = Gravity.CENTER_VERTICAL;
            badge.setLayoutParams(badgeLp);

            // Heading
            TextView heading = new TextView(a);
            heading.setText(item[0]);
            heading.setTextColor(textColor);
            heading.setTextSize(15f);
            heading.setTypeface(Typeface.DEFAULT_BOLD);
            heading.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (L10n.rtl()) {
                row.addView(badge);
                row.addView(heading);
            } else {
                row.addView(heading);
                row.addView(badge);
            }
            card.addView(row);

            // Separator
            View sep = new View(a);
            sep.setBackgroundColor(p.a ? 0x22FFFFFF : 0x11000000);
            LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
            sepLp.setMargins(0, dp(a, 10), 0, dp(a, 10));
            sep.setLayoutParams(sepLp);
            card.addView(sep);

            // Dhikr text
            TextView body = new TextView(a);
            body.setText(item[1]);
            body.setTextColor(textColor);
            body.setTextSize(16f);
            body.setLineSpacing(dp(a, 4), 1f);
            if (L10n.rtl()) body.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
            card.addView(body);

            root.addView(card);
        }

        new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(title)
            .setView(scroll)
            .setNegativeButton(Ui.s("إغلاق", "Close"), null)
            .show();
    }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
