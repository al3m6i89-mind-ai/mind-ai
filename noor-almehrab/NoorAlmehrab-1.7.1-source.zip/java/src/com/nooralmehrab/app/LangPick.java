package com.nooralmehrab.app;

/** Called when a language chip is tapped. */
public final class LangPick implements B1.l {
    private final MainActivity act;

    public LangPick(MainActivity act) { this.act = act; }

    @Override
    public Object h(Object o) {
        int lang = ((Enum) o).ordinal();
        if (lang != L10n.lang()) L10n.switchTo(act, lang);
        return q1.g.a;
    }
}
