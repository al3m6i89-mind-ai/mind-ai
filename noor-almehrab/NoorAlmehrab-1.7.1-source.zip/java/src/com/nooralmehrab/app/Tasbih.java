package com.nooralmehrab.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Digital tasbih counter. */
public final class Tasbih {
    private Tasbih() {}

    private static final String PREF = "tasbih";
    private static final String KEY_COUNT = "count";
    private static final String KEY_TARGET = "target";

    private static final int[] TARGETS = {33, 99, 100, 1000};

    public static void open(final MainActivity a) {
        p1.c p = Ui.pal(a);
        SharedPreferences sp = a.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        final int[] count = {sp.getInt(KEY_COUNT, 0)};
        final int[] targetIdx = {0};
        // find current target index
        int saved = sp.getInt(KEY_TARGET, 33);
        for (int i = 0; i < TARGETS.length; i++) if (TARGETS[i] == saved) { targetIdx[0] = i; break; }

        int bg = p.b;
        int cardBg = p.d;
        int textColor = p.i;
        int accent = p.g;

        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(a, 20);
        root.setPadding(pad, pad, pad, pad);

        // Target selector label
        final TextView targetLabel = new TextView(a);
        targetLabel.setTextColor(p.j);
        targetLabel.setTextSize(13f);
        targetLabel.setGravity(Gravity.CENTER);
        targetLabel.setText(Ui.f("الهدف: %s", "Target: %s", TARGETS[targetIdx[0]]));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMargins(0, 0, 0, dp(a, 8));
        targetLabel.setLayoutParams(tlp);
        root.addView(targetLabel);

        // Count display
        final TextView countView = new TextView(a);
        countView.setTextSize(72f);
        countView.setTypeface(Typeface.DEFAULT_BOLD);
        countView.setTextColor(accent);
        countView.setGravity(Gravity.CENTER);
        countView.setText(String.valueOf(count[0]));
        LinearLayout.LayoutParams cvlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cvlp.setMargins(0, 0, 0, dp(a, 16));
        countView.setLayoutParams(cvlp);
        root.addView(countView);

        // Progress bar (simple view)
        final View progressBar = new View(a);
        final int[] barParams = {0, TARGETS[targetIdx[0]]};
        updateProgressBar(progressBar, count[0], TARGETS[targetIdx[0]], accent, a);
        LinearLayout.LayoutParams pblp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 8));
        pblp.setMargins(0, 0, 0, dp(a, 24));
        progressBar.setLayoutParams(pblp);
        root.addView(progressBar);

        // Tap button
        View tapBtn = makeButton(a, Ui.s("اضغط للتسبيح", "Tap to count"), accent, p.h, 64f, dp(a, 80));
        LinearLayout.LayoutParams btnlp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 100));
        btnlp.setMargins(0, 0, 0, dp(a, 16));
        tapBtn.setLayoutParams(btnlp);
        root.addView(tapBtn);

        // Bottom row: reset + change target
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View resetBtn = makeButton(a, Ui.s("إعادة", "Reset"), p.e, p.i, 14f, 0);
        resetBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(a, 44), 1f));
        View changeBtn = makeButton(a, Ui.s("تغيير الهدف", "Change target"), p.e, p.i, 14f, 0);
        changeBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(a, 44), 1f));
        ((LinearLayout.LayoutParams) changeBtn.getLayoutParams()).setMargins(dp(a, 8), 0, 0, 0);
        row.addView(resetBtn);
        row.addView(changeBtn);
        root.addView(row);

        final Vibrator vib = (Vibrator) a.getSystemService(Context.VIBRATOR_SERVICE);

        tapBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                count[0]++;
                countView.setText(String.valueOf(count[0]));
                updateProgressBar(progressBar, count[0], TARGETS[targetIdx[0]], accent, a);
                a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putInt(KEY_COUNT, count[0]).apply();
                try { if (vib != null) vib.vibrate(30L); } catch (Throwable ignored) {}
                if (count[0] == TARGETS[targetIdx[0]]) {
                    Ui.toast(a, Ui.s("أحسنت! اكتمل العدد ✓", "Done! Count complete ✓"));
                }
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                count[0] = 0;
                countView.setText("0");
                updateProgressBar(progressBar, 0, TARGETS[targetIdx[0]], accent, a);
                a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putInt(KEY_COUNT, 0).apply();
            }
        });

        changeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                targetIdx[0] = (targetIdx[0] + 1) % TARGETS.length;
                int t = TARGETS[targetIdx[0]];
                targetLabel.setText(Ui.f("الهدف: %s", "Target: %s", t));
                updateProgressBar(progressBar, count[0], t, accent, a);
                a.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putInt(KEY_TARGET, t).apply();
            }
        });

        new AlertDialog.Builder(a, p.a ? 4 : 5)
            .setTitle(Ui.s("السبحة", "Tasbih"))
            .setView(root)
            .setNegativeButton(Ui.s("إغلاق", "Close"), null)
            .show();
    }

    private static void updateProgressBar(View v, int count, int target, int accent, Context c) {
        try {
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor((accent & 0x00FFFFFF) | 0x33000000);
            bg.setCornerRadius(dp(c, 4));
            android.graphics.drawable.GradientDrawable fg = new android.graphics.drawable.GradientDrawable();
            fg.setColor(accent);
            fg.setCornerRadius(dp(c, 4));
            android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(
                fg, android.view.Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL);
            android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{bg, clip});
            v.setBackground(ld);
            int level = target > 0 ? Math.min(10000, (int)(count * 10000L / target)) : 0;
            clip.setLevel(level);
        } catch (Throwable ignored) {}
    }

    private static View makeButton(Context c, String label, int color, int textColor, float textSize, int minH) {
        TextView tv = new TextView(c);
        tv.setText(label);
        tv.setTextColor(textColor);
        tv.setTextSize(textSize);
        tv.setGravity(Gravity.CENTER);
        if (minH > 0) tv.setMinHeight(minH);
        try {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(color);
            gd.setCornerRadius(dp(c, 12));
            tv.setBackground(gd);
        } catch (Throwable ignored) {}
        return tv;
    }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
}
