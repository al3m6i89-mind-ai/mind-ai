package com.nooralmehrab.app;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Small view helpers that follow the app's own look: rounded cards, palette colours, gold accent. */
final class Ui {
    private Ui() {}

    static String s(String ar, String en) {
        return L10n.en() ? L10n.x(en) : ar;
    }

    /** Like {@link #s} for text with values in it ("%s" placeholders). */
    static String f(String ar, String en, Object... args) {
        return String.format(java.util.Locale.ROOT, s(ar, en), args);
    }

    /** Arabic-Indic digits in Arabic mode. */
    static String n(long v) {
        String d = String.valueOf(v);
        if (L10n.en()) return d;
        StringBuilder b = new StringBuilder();
        for (char ch : d.toCharArray()) b.append(ch >= '0' && ch <= '9' ? (char) ('٠' + (ch - '0')) : ch);
        return b.toString();
    }

    static String ar(long v) {
        String d = String.valueOf(v);
        StringBuilder b = new StringBuilder();
        for (char ch : d.toCharArray()) b.append((char) ('٠' + (ch - '0')));
        return b.toString();
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static p1.c pal(MainActivity a) {
        return a.q;
    }

    static GradientDrawable round(Context c, int color, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radius));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static Drawable ripple(Context c, Drawable content, int color) {
        int rc = (color & 0x00FFFFFF) | 0x33000000;
        return new RippleDrawable(ColorStateList.valueOf(rc), content, null);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return t;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(MainActivity a) {
        p1.c p = pal(a);
        LinearLayout l = vbox(a);
        l.setBackground(round(a, p.d, 16, p.f));
        int pad = dp(a, 14);
        l.setPadding(pad, pad, pad, pad);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h, float weight, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = top;
        return p;
    }

    static LinearLayout.LayoutParams full(Context c, int topDp) {
        return lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(c, topDp));
    }

    static TextView button(MainActivity a, String label, boolean primary) {
        p1.c p = pal(a);
        TextView t = text(a, label, 14, primary ? p.h : p.i, true);
        t.setGravity(Gravity.CENTER);
        int v = dp(a, 12);
        t.setPadding(v, v, v, v);
        GradientDrawable bg = primary ? round(a, p.g, 12, 0) : round(a, p.e, 12, p.f);
        t.setBackground(ripple(a, bg, primary ? p.h : p.g));
        t.setClickable(true);
        return t;
    }

    /** Section title in the same gold style the settings screen uses. */
    static TextView title(MainActivity a, String s) {
        TextView t = text(a, s, 15, pal(a).g, true);
        t.setPadding(dp(a, 4), 0, dp(a, 4), 0);
        return t;
    }

    /** Full-screen page with a header (title + close) and a scrolling body. Returns the body. */
    static LinearLayout page(final MainActivity a, final Dialog d, String title) {
        p1.c p = pal(a);
        LinearLayout root = vbox(a);
        root.setBackgroundColor(p.b);
        L10n.dir(root, View.LAYOUT_DIRECTION_RTL);

        LinearLayout head = hbox(a);
        head.setPadding(dp(a, 18), dp(a, 14), dp(a, 18), dp(a, 8));
        TextView t = text(a, title, 21, p.i, true);
        head.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text(a, "✕", 16, p.i, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(ripple(a, round(a, p.d, 22, p.f), p.g));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        head.addView(close, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        LinearLayout body = vbox(a);
        body.setPadding(dp(a, 18), dp(a, 4), dp(a, 18), dp(a, 32));
        sv.addView(body, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(p.b));
            w.setStatusBarColor(p.b);
            w.setNavigationBarColor(p.b);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        return body;
    }

    static Dialog dialog(MainActivity a) {
        // Same full-screen themes the settings screen uses.
        return new Dialog(a, pal(a).a ? 0x103022e : 0x1030241);
    }

    static void toast(Context c, String s) {
        android.widget.Toast.makeText(c, s, android.widget.Toast.LENGTH_LONG).show();
    }
}
