package com.nooralmehrab.app;

import android.app.Dialog;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Quran reciters: the user picks a reciter and a surah, and the surah is recited
 * ayah by ayah (streamed from the Islamic Network CDN). The ayah being recited is
 * highlighted and scrolled into view. Playback can be paused or stopped.
 */
public final class Reciters {
    private Reciters() {}

    // Verified ayah-by-ayah editions on https://cdn.islamic.network/quran/audio/<bitrate>/<edition>/<n>.mp3
    // (identifiers and bitrates confirmed against the alquran.cloud API).
    static final String[] NAME_AR = {
        "مشاري العفاسي",
        "عبد الباسط عبد الصمد",
        "عبد الرحمن السديس",
        "سعود الشريم",
        "ماهر المعيقلي",
        "محمود خليل الحصري",
        "أحمد العجمي",
        "علي الحذيفي",
        "أبو بكر الشاطري",
        "هاني الرفاعي",
        "محمد أيوب",
        "محمد جبريل",
    };
    static final String[] NAME_EN = {
        "Mishary Alafasy", "Abdul Basit Abdus-Samad", "Abdurrahman As-Sudais", "Saud Al-Shuraim",
        "Maher Al-Muaiqly", "Mahmoud Al-Husary", "Ahmed Al-Ajamy", "Ali Al-Hudhaify",
        "Abu Bakr Ash-Shaatree", "Hani Ar-Rifai", "Muhammad Ayyoub", "Muhammad Jibreel",
    };
    static final String[] EDITION = {
        "ar.alafasy", "ar.abdulsamad", "ar.abdurrahmaansudais", "ar.saoodshuraym",
        "ar.mahermuaiqly", "ar.husary", "ar.ahmedajamy", "ar.hudhaify",
        "ar.shaatree", "ar.hanirifai", "ar.muhammadayyoub", "ar.muhammadjibreel",
    };
    static final int[] BITRATE = { 128, 64, 192, 64, 128, 128, 128, 128, 128, 192, 128, 128 };

    static void open(final MainActivity a) {
        p1.c p = Ui.pal(a);
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(a, p.a ? 4 : 5);
        b.setTitle(Ui.s("اختر القارئ", "Choose a reciter"));
        String[] items = new String[NAME_AR.length];
        for (int i = 0; i < items.length; i++) items[i] = L10n.latin() ? NAME_EN[i] : NAME_AR[i];
        b.setItems(items, new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface d, int which) {
                pickSurah(a, which);
            }
        });
        android.app.AlertDialog d = b.show();
        if (d.getWindow() != null) {
            L10n.dir(d.getWindow().getDecorView(), View.LAYOUT_DIRECTION_RTL);
        }
    }

    private static void pickSurah(final MainActivity a, final int reciter) {
        Features.withQuran(a, new Features.Then() {
            @Override public void run() {
                final p1.c p = Ui.pal(a);
                final Dialog d = Ui.dialog(a);
                LinearLayout body = Ui.page(a, d, Ui.s("اختر السورة", "Choose a surah"));
                TextView who = Ui.text(a, Ui.s("القارئ: ", "Reciter: ")
                        + (L10n.latin() ? NAME_EN[reciter] : NAME_AR[reciter]), 14, p.g, true);
                body.addView(who, Ui.full(a, 4));
                for (int i = 1; i <= 114; i++) {
                    final int s = i;
                    LinearLayout row = Ui.hbox(a);
                    int v = Ui.dp(a, 10);
                    row.setPadding(v, v, v, v);
                    row.setBackground(Ui.ripple(a, Ui.round(a, p.d, 14, p.f), p.g));
                    TextView num = Ui.text(a, Ui.n(s), 14, p.h, true);
                    num.setGravity(Gravity.CENTER);
                    num.setBackground(Ui.round(a, p.g, 18, 0));
                    row.addView(num, new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
                    LinearLayout col = Ui.vbox(a);
                    col.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 12), 0);
                    col.addView(Ui.text(a, L10n.latin() ? Quran.nameEn[s - 1] : "سورة " + Quran.nameAr[s - 1], 16, p.i, true));
                    col.addView(Ui.text(a, Ui.n(Quran.count(s)) + Ui.s(" آية", " verses"), 12, p.j, false));
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    TextView arn = Ui.text(a, Quran.nameAr[s - 1], 18, p.g, false);
                    if (Quran.font != null) arn.setTypeface(Quran.font);
                    row.addView(arn);
                    row.setClickable(true);
                    row.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View view) { d.dismiss(); player(a, reciter, s); }
                    });
                    body.addView(row, Ui.full(a, s == 1 ? 8 : 6));
                }
                d.show();
            }
        });
    }

    /** Running player for one surah; holds the media player, the ayah views and UI state. */
    static final class Player {
        final MainActivity a;
        final p1.c p;
        final int reciter, surah, count, offset;
        final TextView[] views;
        final ScrollView scroll;
        final TextView playBtn;
        MediaPlayer mp;
        int cur;            // currently highlighted ayah (1-based); 0 = none
        boolean paused;
        boolean released;

        Player(MainActivity a, int reciter, int surah, TextView[] views, ScrollView scroll, TextView playBtn) {
            this.a = a; this.p = Ui.pal(a);
            this.reciter = reciter; this.surah = surah;
            this.count = Quran.count(surah);
            int off = 0;
            for (int i = 1; i < surah; i++) off += Quran.count(i);
            this.offset = off;
            this.views = views; this.scroll = scroll; this.playBtn = playBtn;
        }

        void toggle() {
            if (released) return;
            if (mp != null && mp.isPlaying()) {
                mp.pause();
                paused = true;
                setIcon();
                return;
            }
            if (mp != null && paused) {
                mp.start();
                paused = false;
                setIcon();
                return;
            }
            play(cur > 0 ? cur : 1);
        }

        void play(final int v) {
            if (released || v < 1 || v > count) { finish(); return; }
            cur = v;
            paused = false;
            highlight(v);
            release();
            String url = "https://cdn.islamic.network/quran/audio/" + BITRATE[reciter]
                    + "/" + EDITION[reciter] + "/" + (offset + v) + ".mp3";
            try {
                mp = new MediaPlayer();
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                mp.setDataSource(url);
                mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override public void onPrepared(MediaPlayer m) {
                        if (released) { m.release(); return; }
                        m.start();
                        setIcon();
                    }
                });
                mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override public void onCompletion(MediaPlayer m) {
                        if (!released) play(cur + 1);
                    }
                });
                mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override public boolean onError(MediaPlayer m, int what, int extra) {
                        if (!released) {
                            Ui.toast(a, Ui.s("تعذّر تشغيل التلاوة، تأكد من الإنترنت.", "Couldn't play the recitation. Check your internet."));
                            stopAll();
                        }
                        return true;
                    }
                });
                mp.prepareAsync();
                setIcon();
            } catch (Throwable t) {
                Ui.toast(a, Ui.s("تعذّر تشغيل التلاوة", "Couldn't play the recitation"));
                stopAll();
            }
        }

        void finish() {
            // reached end of surah
            stopAll();
        }

        void stopAll() {
            release();
            cur = 0;
            paused = false;
            setIcon();
            for (TextView t : views) t.setBackground(Ui.round(a, p.d, 12, 0));
        }

        private void release() {
            if (mp != null) {
                try { mp.reset(); mp.release(); } catch (Throwable ignored) {}
                mp = null;
            }
        }

        void dispose() {
            released = true;
            release();
        }

        private void setIcon() {
            boolean playing = mp != null && !paused;
            playBtn.setText(playing ? "‖" : "▶");
        }

        private void highlight(final int v) {
            for (int i = 0; i < views.length; i++) {
                views[i].setBackground(Ui.round(a, (i + 1) == v ? p.e : p.d, 12, (i + 1) == v ? p.g : 0));
            }
            final TextView t = views[v - 1];
            scroll.post(new Runnable() {
                @Override public void run() {
                    scroll.smoothScrollTo(0, Math.max(0, t.getTop() - Ui.dp(a, 90)));
                }
            });
        }
    }

    static void player(final MainActivity a, final int reciter, final int s) {
        Features.withQuran(a, new Features.Then() {
            @Override public void run() { build(a, reciter, s); }
        });
    }

    private static void build(final MainActivity a, final int reciter, final int s) {
        final p1.c p = Ui.pal(a);
        final Dialog d = Ui.dialog(a);

        LinearLayout root = Ui.vbox(a);
        root.setBackgroundColor(p.b);
        L10n.dir(root, View.LAYOUT_DIRECTION_RTL);

        // header
        LinearLayout head = Ui.hbox(a);
        head.setPadding(Ui.dp(a, 18), Ui.dp(a, 14), Ui.dp(a, 18), Ui.dp(a, 8));
        LinearLayout titles = Ui.vbox(a);
        titles.addView(Ui.text(a, L10n.latin() ? L10n.x("Surah ") + Quran.nameEn[s - 1] : "سورة " + Quran.nameAr[s - 1], 20, p.i, true));
        titles.addView(Ui.text(a, L10n.latin() ? NAME_EN[reciter] : NAME_AR[reciter], 13, p.g, true));
        head.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.text(a, "✕", 16, p.i, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(Ui.ripple(a, Ui.round(a, p.d, 22, p.f), p.g));
        head.addView(close, new LinearLayout.LayoutParams(Ui.dp(a, 44), Ui.dp(a, 44)));
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ayah list
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        LinearLayout body = Ui.vbox(a);
        body.setPadding(Ui.dp(a, 16), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 24));
        int count = Quran.count(s);
        TextView[] views = new TextView[count];
        for (int v = 1; v <= count; v++) {
            TextView t = Features.quranText(a, Quran.range(s, v, v), 24);
            int pad = Ui.dp(a, 8);
            t.setPadding(pad, pad, pad, pad);
            t.setBackground(Ui.round(a, p.d, 12, 0));
            views[v - 1] = t;
            body.addView(t, Ui.full(a, v == 1 ? 8 : 6));
        }
        sv.addView(body, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // controls
        LinearLayout bar = Ui.hbox(a);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(Ui.dp(a, 16), Ui.dp(a, 10), Ui.dp(a, 16), Ui.dp(a, 18));
        bar.setBackgroundColor(p.d);
        TextView prev = roundBtn(a, "⏮", false);
        final TextView playBtn = roundBtn(a, "▶", true);
        TextView next = roundBtn(a, "⏭", false);
        TextView stop = roundBtn(a, "■", false);
        bar.addView(prev, btnLp(a, 48, false));
        bar.addView(playBtn, btnLp(a, 60, true));
        bar.addView(next, btnLp(a, 48, true));
        bar.addView(stop, btnLp(a, 48, true));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final Player player = new Player(a, reciter, s, views, sv, playBtn);

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { player.toggle(); }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { player.play(Math.max(1, (player.cur > 0 ? player.cur : 1) - 1)); }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { player.play((player.cur > 0 ? player.cur : 0) + 1); }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { player.stopAll(); }
        });
        // tap an ayah to start from it
        for (int v = 1; v <= count; v++) {
            final int vv = v;
            views[v - 1].setClickable(true);
            views[v - 1].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { player.play(vv); }
            });
        }
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface di) { player.dispose(); }
        });

        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(p.b));
            w.setStatusBarColor(p.b);
            w.setNavigationBarColor(p.d);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        d.show();
    }

    private static TextView roundBtn(MainActivity a, String glyph, boolean primary) {
        p1.c p = Ui.pal(a);
        TextView t = Ui.text(a, glyph, primary ? 22 : 18, primary ? p.h : p.i, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.ripple(a, Ui.round(a, primary ? p.g : p.e, primary ? 30 : 24, primary ? 0 : p.f), primary ? p.h : p.g));
        t.setClickable(true);
        return t;
    }

    private static LinearLayout.LayoutParams btnLp(MainActivity a, int sizeDp, boolean margin) {
        int sz = Ui.dp(a, sizeDp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sz, sz);
        if (margin) lp.setMarginStart(Ui.dp(a, 14));
        return lp;
    }
}
