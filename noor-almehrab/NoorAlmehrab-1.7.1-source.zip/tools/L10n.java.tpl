package com.nooralmehrab.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Process;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * App language: Arabic, English, Turkish or Urdu. Arabic is the source text; English comes from the
 * table below, and Turkish / Urdu are looked up from the English text in {@link L10nX}.
 */
public final class L10n {
    private static final String PREFS = "noor_lang";
    private static final String KEY = "lang";
    static final String[] CODES = {"ar", "en", "tr", "ur"};

    /** -1 = not loaded yet, otherwise an index into CODES. */
    private static volatile int state = -1;
    private static HashMap<String, String> ar2en;
    private static HashMap<String, String> any2ar;

    private L10n() {}

    public static void init(Context c) {
        if (c == null) return;
        try {
            SharedPreferences p = c.getApplicationContext() != null
                    ? c.getApplicationContext().getSharedPreferences(PREFS, 0)
                    : c.getSharedPreferences(PREFS, 0);
            String v = p.getString(KEY, "ar");
            int s = 0;
            for (int i = 0; i < CODES.length; i++) if (CODES[i].equals(v)) s = i;
            state = s;
        } catch (Throwable ignored) {
        }
    }

    public static int lang() {
        if (state < 0) init(currentApp());
        return state < 0 ? 0 : state;
    }

    /** True for every language except Arabic (the UI text is translated). */
    public static boolean en() {
        return lang() != 0;
    }

    /** Languages written right to left: Arabic and Urdu. */
    public static boolean rtl() {
        int l = lang();
        return l == 0 || l == 3;
    }

    /** Languages in Latin script (English, Turkish): proper names are shown transliterated. */
    public static boolean latin() {
        int l = lang();
        return l == 1 || l == 2;
    }

    private static Context currentApp() {
        try {
            return (Context) Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            return null;
        }
    }

    /** English text in the current language (Turkish / Urdu from the table, English otherwise). */
    public static String x(String en) {
        if (en == null) return null;
        int l = lang();
        if (l < 2) return en;
        String r = L10nX.get(l, en);
        return r != null ? r : en;
    }

    static String[] xa(String[] en) {
        String[] r = new String[en.length];
        for (int i = 0; i < en.length; i++) r[i] = x(en[i]);
        return r;
    }

    /** Translates a built-in Arabic UI string. */
    public static String t(String s) {
        if (s == null || !en()) return s;
        String r = table().get(s);
        return r != null ? x(r) : s;
    }

    /** Translates a value saved in settings, which may have been saved in any language. */
    public static String tp(String s) {
        if (s == null) return null;
        HashMap<String, String> m = table();
        String ar = m.containsKey(s) ? s : any2ar.get(s);
        if (ar == null) return s;
        return t(ar);
    }

    /** Release notes from update.json in the current language (English when missing). */
    static String notes(org.json.JSONObject j) {
        int l = lang();
        if (l == 0) return j.optString("notes_ar", "");
        String en = j.optString("notes_en", "");
        return l == 1 ? en : j.optString("notes_" + CODES[l], en);
    }

    public static String title() {
        return Ui.s("اللغة", "Language");
    }

    /** Geocoder language for place names. */
    public static String geo(String s) {
        return en() ? CODES[lang()] : s;
    }

    /** The UI was written RTL; English and Turkish use LTR. */
    public static void dir(View v, int d) {
        if (d == View.LAYOUT_DIRECTION_RTL && !rtl()) d = View.LAYOUT_DIRECTION_LTR;
        v.setLayoutDirection(d);
    }

    public static void tg(TextView v, int g) {
        v.setGravity(mirror(g));
    }

    public static void lg(LinearLayout v, int g) {
        v.setGravity(mirror(g));
    }

    /** Absolute LEFT/RIGHT gravity was written for RTL; flip it for LTR. Relative START/END is left alone. */
    private static int mirror(int g) {
        if (rtl() || (g & 0x800000) != 0) return g;
        int h = g & 7;
        if (h == 3) return (g & ~7) | 5;
        if (h == 5) return (g & ~7) | 3;
        return g;
    }

    public static Context wrap(Context base) {
        init(base);
        if (!en() || base == null) return base;
        try {
            Locale loc = new Locale(CODES[lang()]);
            Configuration c = new Configuration(base.getResources().getConfiguration());
            c.setLocale(loc);
            c.setLayoutDirection(loc);
            return base.createConfigurationContext(c);
        } catch (Throwable t) {
            return base;
        }
    }

    public static void switchTo(Activity a, boolean english) {
        switchTo(a, english ? 1 : 0);
    }

    /** Saves the choice and restarts the app so every screen, list and notification text reloads. */
    public static void switchTo(Activity a, int lang) {
        a.getApplicationContext().getSharedPreferences(PREFS, 0).edit()
                .putString(KEY, CODES[lang]).commit();
        state = lang;
        try {
            Intent i = new Intent(a, Restart.class);
            i.putExtra("pid", Process.myPid());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
            a.finish();
        } catch (Throwable t) {
            a.recreate();
        }
    }

    private static synchronized HashMap<String, String> table() {
        if (ar2en == null) {
            HashMap<String, String> m = new HashMap<>(512);
//@CALLS
            HashMap<String, String> r = new HashMap<>(1024);
            for (Map.Entry<String, String> e : m.entrySet()) {
                String v = e.getValue();
                if (v.trim().length() <= 1) continue;
                if (!r.containsKey(v)) r.put(v, e.getKey());
                for (int l = 2; l < CODES.length; l++) {
                    String o = L10nX.get(l, v);
                    if (o != null && o.trim().length() > 1 && !r.containsKey(o)) r.put(o, e.getKey());
                }
            }
            any2ar = r;
            ar2en = m;
        }
        return ar2en;
    }

//@METHODS
}
