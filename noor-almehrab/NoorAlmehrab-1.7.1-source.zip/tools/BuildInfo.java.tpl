package com.nooralmehrab.app;

/** Filled in by the build script. */
final class BuildInfo {
    private BuildInfo() {}

    static final String VERSION = "@VERSION@";
    static final String BUILT = "@BUILT@";
    static final String UPDATE_URL = "@UPDATE_URL@";
}
