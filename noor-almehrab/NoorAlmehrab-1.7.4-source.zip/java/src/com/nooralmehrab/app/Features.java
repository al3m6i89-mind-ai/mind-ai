package com.nooralmehrab.app;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.text.LineBreaker;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Home shortcuts (Khatma, Ruqyah, nearby mosques) and the extra settings cards. */
public final class Features {
    private Features() {}

    static final String PREFS = "noor_extra";

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, 0);
    }

    // ---------------------------------------------------------------- home

    /** Called while the main screen is built; adds the "More" card under today's prayer times. */
    public static void home(final MainActivity a, LinearLayout content) {
        if (a.u != 0) return;
        try {
            addSunCard(a, content);
            a.h(content, Ui.s("المزيد", "More"), new B1.l() {
                @Override public Object h(Object o) {
                    LinearLayout card = (LinearLayout) o;
                    LinearLayout row = Ui.hbox(a);
                    row.addView(tile(a, "📗", Ui.s("المصحف", "Quran"), new View.OnClickListener() {
                        @Override public void onClick(View v) { openMushaf(a); }
                    }), tileLp(a, false));
                    row.addView(tile(a, "📖", Ui.s("الختمة", "Khatma"), new View.OnClickListener() {
                        @Override public void onClick(View v) { openKhatma(a); }
                    }), tileLp(a, true));
                    card.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    LinearLayout row2 = Ui.hbox(a);
                    row2.addView(tile(a, "🛡️", Ui.s("الرقية الشرعية", "Ruqyah"), new View.OnClickListener() {
                        @Override public void onClick(View v) { openRuqyah(a); }
                    }), tileLp(a, false));
                    row2.addView(tile(a, "🕌", Ui.s("المساجد القريبة", "Nearby mosques"), new View.OnClickListener() {
                        @Override public void onClick(View v) { openMosques(a); }
                    }), tileLp(a, true));
                    card.addView(row2, Ui.full(a, 8));
                    LinearLayout row3 = Ui.hbox(a);
                    row3.addView(tile(a, "🎧", Ui.s("القرّاء", "Reciters"), new View.OnClickListener() {
                        @Override public void onClick(View v) { Reciters.open(a); }
                    }), tileLp(a, false));
                    card.addView(row3, Ui.full(a, 8));
                    return q1.g.a;
                }
            });
            a.h(content, Ui.s("أدواتي", "My Tools"), new B1.l() {
                @Override public Object h(Object o) {
                    LinearLayout card = (LinearLayout) o;
                    LinearLayout r1 = Ui.hbox(a);
                    r1.addView(tile(a, "📿", Ui.s("الأذكار", "Adhkar"), new View.OnClickListener() {
                        @Override public void onClick(View v) { Adhkar.open(a); }
                    }), tileLp(a, false));
                    r1.addView(tile(a, "☪", Ui.s("السبحة", "Tasbih"), new View.OnClickListener() {
                        @Override public void onClick(View v) { Tasbih.open(a); }
                    }), tileLp(a, true));
                    card.addView(r1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    LinearLayout r2 = Ui.hbox(a);
                    r2.addView(tile(a, "✅", Ui.s("تتبع صلواتي", "Prayer Log"), new View.OnClickListener() {
                        @Override public void onClick(View v) { PrayerLog.open(a); }
                    }), tileLp(a, false));
                    r2.addView(tile(a, "🔍", Ui.s("بحث القرآن", "Search Quran"), new View.OnClickListener() {
                        @Override public void onClick(View v) { QuranSearch.open(a); }
                    }), tileLp(a, true));
                    card.addView(r2, Ui.full(a, 8));
                    LinearLayout r3 = Ui.hbox(a);
                    r3.addView(tile(a, "📅", Ui.s("التقويم الهجري", "Hijri Calendar"), new View.OnClickListener() {
                        @Override public void onClick(View v) { HijriCalendar.open(a); }
                    }), tileLp(a, false));
                    r3.addView(tile(a, "🔔", Ui.s("تنبيه الصلاة", "Prayer Alert"), new View.OnClickListener() {
                        @Override public void onClick(View v) { PrayerAlerts.openSettings(a); }
                    }), tileLp(a, true));
                    card.addView(r3, Ui.full(a, 8));
                    return q1.g.a;
                }
            });
        } catch (Throwable ignored) {
        }
    }

    /** A card showing today's sunrise (الشروق) and sunset (الغروب) for the user's location. */
    private static void addSunCard(final MainActivity a, LinearLayout content) {
        try {
            Double lat = a.g().a, lng = a.g().b;
            if (lat == null || lng == null) return;
            final long[] t = SunTimes.today(lat, lng);
            if (t == null) return;
            a.h(content, Ui.s("الشروق والغروب", "Sunrise & sunset"), new B1.l() {
                @Override public Object h(Object o) {
                    LinearLayout card = (LinearLayout) o;
                    LinearLayout row = Ui.hbox(a);
                    row.addView(sunCol(a, "🌅", Ui.s("الشروق", "Sunrise"), SunTimes.fmt(t[0])),
                            new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    row.addView(sunCol(a, "🌇", Ui.s("الغروب", "Sunset"), SunTimes.fmt(t[1])),
                            new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    card.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    return q1.g.a;
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static View sunCol(MainActivity a, String icon, String label, String time) {
        p1.c p = Ui.pal(a);
        LinearLayout col = Ui.vbox(a);
        col.setGravity(Gravity.CENTER);
        int v = Ui.dp(a, 6);
        col.setPadding(v, v, v, v);
        TextView ic = Ui.text(a, icon, 22, p.i, false);
        ic.setGravity(Gravity.CENTER);
        col.addView(ic);
        TextView lb = Ui.text(a, label, 13, p.j, false);
        lb.setGravity(Gravity.CENTER);
        col.addView(lb, Ui.full(a, 2));
        TextView tm = Ui.text(a, time, 18, p.g, true);
        tm.setGravity(Gravity.CENTER);
        col.addView(tm, Ui.full(a, 2));
        return col;
    }

    private static LinearLayout.LayoutParams tileLp(Context c, boolean gap) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        if (gap) p.setMarginStart(Ui.dp(c, 8));
        return p;
    }

    private static View tile(MainActivity a, String icon, String label, View.OnClickListener l) {
        p1.c p = Ui.pal(a);
        LinearLayout t = Ui.vbox(a);
        t.setGravity(Gravity.CENTER);
        int v = Ui.dp(a, 12);
        t.setPadding(Ui.dp(a, 4), v, Ui.dp(a, 4), v);
        t.setBackground(Ui.ripple(a, Ui.round(a, p.e, 14, p.f), p.g));
        TextView i = Ui.text(a, icon, 24, p.i, false);
        i.setGravity(Gravity.CENTER);
        t.addView(i);
        TextView s = Ui.text(a, label, 13, p.i, true);
        s.setGravity(Gravity.CENTER);
        s.setMaxLines(2);
        t.addView(s, Ui.full(a, 6));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    // ---------------------------------------------------------------- mosques

    static void openMosques(MainActivity a) {
        Double lat = null, lng = null;
        try {
            lat = a.g().a;
            lng = a.g().b;
        } catch (Throwable ignored) {
        }
        String q = Ui.s("مساجد", "mosque");
        String at = lat != null && lng != null ? lat + "," + lng : "0,0";
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + at + "?q=" + Uri.encode(q)));
            a.startActivity(i);
            return;
        } catch (ActivityNotFoundException ignored) {
        } catch (Throwable ignored) {
        }
        try {
            String url = "https://www.google.com/maps/search/" + Uri.encode(q)
                    + (lat != null && lng != null ? "/@" + lat + "," + lng + ",15z" : "");
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable t) {
            Ui.toast(a, Ui.s("لا يوجد تطبيق خرائط على الجهاز", "No maps app found on this device"));
        }
    }

    // ---------------------------------------------------------------- Quran loading

    interface Then {
        void run();
    }

    static void withQuran(final MainActivity a, final Then then) {
        if (Quran.ayat != null) {
            then.run();
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = true;
                try {
                    Quran.load(a);
                } catch (Throwable t) {
                    ok = false;
                }
                final boolean fine = ok;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override public void run() {
                        if (a.isFinishing()) return;
                        if (fine) then.run();
                        else Ui.toast(a, Ui.s("تعذّر فتح المصحف", "Could not open the Quran text"));
                    }
                });
            }
        }).start();
    }

    /** Quran text view: right-to-left, large, justified. */
    static TextView quranText(MainActivity a, String s, float sp) {
        p1.c p = Ui.pal(a);
        TextView t = Ui.text(a, s, sp, p.i, false);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        t.setGravity(Gravity.START);
        if (Quran.font != null) t.setTypeface(Quran.font);
        t.setIncludeFontPadding(true);
        t.setLineSpacing(0f, 1.6f);
        if (Build.VERSION.SDK_INT >= 26) t.setJustificationMode(LineBreaker.JUSTIFICATION_MODE_INTER_WORD);
        t.setTextIsSelectable(false);
        return t;
    }

    static TextView surahHeader(MainActivity a, int s) {
        p1.c p = Ui.pal(a);
        String label = L10n.en() ? "Surah " + Quran.nameEn[s - 1] + " · " + Quran.nameAr[s - 1]
                : "سورة " + Quran.nameAr[s - 1];
        TextView t = Ui.text(a, label, 17, p.g, true);
        t.setGravity(Gravity.CENTER);
        int v = Ui.dp(a, 10);
        t.setPadding(v, v, v, v);
        t.setBackground(Ui.round(a, p.e, 14, p.g));
        return t;
    }

    static String basmala() {
        return Quran.ayat[0][0];
    }

    /** Adds verses in chunks so long surahs stay quick to lay out. */
    static void addVerses(MainActivity a, LinearLayout into, int s, int from, int to, float sp, int topDp) {
        for (int v = from; v <= to; v += 15) {
            int e = Math.min(to, v + 14);
            into.addView(quranText(a, Quran.range(s, v, e), sp), Ui.full(a, v == from ? topDp : 0));
        }
    }

    // ---------------------------------------------------------------- Mushaf

    static void openMushaf(final MainActivity a) {
        withQuran(a, new Then() {
            @Override public void run() {
                final p1.c p = Ui.pal(a);
                Dialog d = Ui.dialog(a);
                LinearLayout body = Ui.page(a, d, Ui.s("المصحف الشريف", "The Holy Quran"));
                final int last = prefs(a).getInt("m_last", 0);
                if (last > 0) {
                    TextView cont = Ui.button(a, Ui.s("متابعة القراءة: سورة ", "Continue reading: Surah ") + Quran.surahName(last), true);
                    cont.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { openSurah(a, last); }
                    });
                    body.addView(cont, Ui.full(a, 6));
                }
                body.addView(Ui.title(a, Ui.s("فهرس السور", "Surahs")), Ui.full(a, 16));
                for (int i = 1; i <= 114; i++) {
                    final int s = i;
                    LinearLayout row = Ui.hbox(a);
                    int v = Ui.dp(a, 10);
                    row.setPadding(v, v, v, v);
                    row.setBackground(Ui.ripple(a, Ui.round(a, p.d, 14, s == last ? p.g : p.f), p.g));
                    TextView num = Ui.text(a, Ui.n(s), 14, p.h, true);
                    num.setGravity(Gravity.CENTER);
                    num.setBackground(Ui.round(a, p.g, 18, 0));
                    row.addView(num, new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
                    LinearLayout col = Ui.vbox(a);
                    col.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 12), 0);
                    TextView name = Ui.text(a, L10n.en() ? Quran.nameEn[s - 1] : "سورة " + Quran.nameAr[s - 1], 16, p.i, true);
                    col.addView(name);
                    String info = (Quran.meccan[s - 1] ? Ui.s("مكية", "Meccan") : Ui.s("مدنية", "Medinan"))
                            + " • " + Ui.n(Quran.count(s)) + Ui.s(" آية", " verses");
                    col.addView(Ui.text(a, info, 12, p.j, false));
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    TextView ar = Ui.text(a, Quran.nameAr[s - 1], 18, p.g, false);
                    if (Quran.font != null) ar.setTypeface(Quran.font);
                    row.addView(ar);
                    row.setClickable(true);
                    row.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View view) { openSurah(a, s); }
                    });
                    body.addView(row, Ui.full(a, s == 1 ? 8 : 6));
                }
                d.show();
            }
        });
    }

    static void openSurah(final MainActivity a, final int s) {
        final p1.c p = Ui.pal(a);
        final Dialog d = Ui.dialog(a);
        LinearLayout body = Ui.page(a, d, L10n.en() ? "Surah " + Quran.nameEn[s - 1] : "سورة " + Quran.nameAr[s - 1]);
        prefs(a).edit().putInt("m_last", s).apply();
        body.addView(surahHeader(a, s), Ui.full(a, 6));
        TextView info = Ui.text(a, (Quran.meccan[s - 1] ? Ui.s("مكية", "Meccan") : Ui.s("مدنية", "Medinan"))
                + " • " + Ui.n(Quran.count(s)) + Ui.s(" آية", " verses"), 12, p.j, false);
        info.setGravity(Gravity.CENTER);
        body.addView(info, Ui.full(a, 6));
        if (s != 1 && s != 9) {
            TextView b = quranText(a, basmala(), 23);
            b.setGravity(Gravity.CENTER);
            b.setTextColor(p.g);
            body.addView(b, Ui.full(a, 10));
        }
        addVerses(a, body, s, 1, Quran.count(s), 24, 10);
        LinearLayout nav = Ui.hbox(a);
        if (s > 1) {
            TextView prev = Ui.button(a, Ui.s("السورة السابقة", "Previous surah"), false);
            prev.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { d.dismiss(); openSurah(a, s - 1); }
            });
            nav.addView(prev, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        if (s < 114) {
            TextView next = Ui.button(a, Ui.s("السورة التالية", "Next surah"), true);
            next.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { d.dismiss(); openSurah(a, s + 1); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (s > 1) lp.setMarginStart(Ui.dp(a, 8));
            nav.addView(next, lp);
        }
        body.addView(nav, Ui.full(a, 24));
        d.show();
    }

    // ---------------------------------------------------------------- Khatma

    static int mask(Context c) { return prefs(c).getInt("k_mask", 0); }

    static int doneCount(int m) { return Integer.bitCount(m & 0x3FFFFFFF); }

    static int nextJuz(Context c) {
        int m = mask(c);
        int last = prefs(c).getInt("k_last", 1);
        for (int i = 0; i < 30; i++) {
            int j = (last - 1 + i) % 30 + 1;
            if ((m & (1 << (j - 1))) == 0) return j;
        }
        return 1;
    }

    static void openKhatma(final MainActivity a) {
        withQuran(a, new Then() {
            @Override public void run() {
                final Dialog d = Ui.dialog(a);
                final LinearLayout body = Ui.page(a, d, Ui.s("الختمة", "Khatma"));
                fillKhatma(a, d, body);
                d.show();
            }
        });
    }

    static void fillKhatma(final MainActivity a, final Dialog d, final LinearLayout body) {
        body.removeAllViews();
        final p1.c p = Ui.pal(a);
        final int m = mask(a);
        int done = doneCount(m);
        int total = prefs(a).getInt("k_count", 0);

        LinearLayout card = Ui.card(a);
        card.addView(Ui.text(a, Ui.s("ختمتك الحالية", "Current khatma"), 14, p.j, true));
        TextView big = Ui.text(a, Ui.n(done) + " / " + Ui.n(30) + Ui.s(" جزءاً", " juz"), 26, p.i, true);
        card.addView(big, Ui.full(a, 4));

        LinearLayout bar = Ui.hbox(a);
        bar.setBackground(Ui.round(a, p.e, 6, 0));
        View fill = new View(a);
        fill.setBackground(Ui.round(a, p.g, 6, 0));
        bar.addView(fill, new LinearLayout.LayoutParams(0, Ui.dp(a, 10), done));
        bar.addView(new View(a), new LinearLayout.LayoutParams(0, Ui.dp(a, 10), 30 - done));
        card.addView(bar, Ui.full(a, 10));

        card.addView(Ui.text(a, Ui.s("الختمات المكتملة: ", "Completed khatmas: ") + Ui.n(total), 14, p.j, false), Ui.full(a, 10));

        final int next = nextJuz(a);
        TextView cont = Ui.button(a, (done == 0 && total == 0 ? Ui.s("ابدأ القراءة: الجزء ", "Start reading: Juz ") : Ui.s("متابعة القراءة: الجزء ", "Continue reading: Juz ")) + Ui.n(next), true);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openJuz(a, next, d, body); }
        });
        card.addView(cont, Ui.full(a, 14));

        if (done > 0) {
            TextView reset = Ui.button(a, Ui.s("بدء ختمة جديدة من الأول", "Start a new khatma"), false);
            reset.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new android.app.AlertDialog.Builder(a, p.a ? 4 : 5)
                            .setMessage(Ui.s("سيتم مسح تقدّم الختمة الحالية. هل أنت متأكد؟", "This clears your current progress. Are you sure?"))
                            .setPositiveButton(Ui.s("نعم", "Yes"), new android.content.DialogInterface.OnClickListener() {
                                @Override public void onClick(android.content.DialogInterface di, int w) {
                                    prefs(a).edit().putInt("k_mask", 0).putInt("k_last", 1).apply();
                                    fillKhatma(a, d, body);
                                }
                            })
                            .setNegativeButton(Ui.s("إلغاء", "Cancel"), null)
                            .show();
                }
            });
            card.addView(reset, Ui.full(a, 8));
        }
        body.addView(card, Ui.full(a, 6));

        body.addView(Ui.title(a, Ui.s("أجزاء القرآن الكريم", "The 30 ajza'")), Ui.full(a, 18));
        body.addView(Ui.text(a, Ui.s("اضغط على الجزء لقراءته، واضغط مطولاً لتعليمه كمقروء أو إلغاء ذلك.",
                "Tap a juz to read it. Long-press to mark it read or unread."), 12, p.j, false), Ui.full(a, 4));

        LinearLayout grid = Ui.vbox(a);
        for (int r = 0; r < 6; r++) {
            LinearLayout row = Ui.hbox(a);
            for (int c = 0; c < 5; c++) {
                final int j = r * 5 + c + 1;
                boolean isDone = (m & (1 << (j - 1))) != 0;
                LinearLayout cell = Ui.vbox(a);
                cell.setGravity(Gravity.CENTER);
                int v = Ui.dp(a, 10);
                cell.setPadding(0, v, 0, v);
                cell.setBackground(Ui.ripple(a, isDone ? Ui.round(a, p.g, 12, 0) : Ui.round(a, p.d, 12, j == next ? p.g : p.f), p.g));
                TextView num = Ui.text(a, Ui.n(j), 17, isDone ? p.h : p.i, true);
                num.setGravity(Gravity.CENTER);
                cell.addView(num);
                TextView sub = Ui.text(a, isDone ? "✓" : Quran.surahName(Quran.JUZ[j - 1][0]), 9, isDone ? p.h : p.j, false);
                sub.setGravity(Gravity.CENTER);
                sub.setSingleLine(true);
                cell.addView(sub);
                cell.setClickable(true);
                cell.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { openJuz(a, j, d, body); }
                });
                cell.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) {
                        int mm = mask(a) ^ (1 << (j - 1));
                        prefs(a).edit().putInt("k_mask", mm).apply();
                        if (doneCount(mm) == 30) completeKhatma(a);
                        fillKhatma(a, d, body);
                        return true;
                    }
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                if (c > 0) lp.setMarginStart(Ui.dp(a, 6));
                row.addView(cell, lp);
            }
            grid.addView(row, Ui.full(a, r == 0 ? 0 : 6));
        }
        body.addView(grid, Ui.full(a, 10));
    }

    static void completeKhatma(MainActivity a) {
        SharedPreferences sp = prefs(a);
        int n = sp.getInt("k_count", 0) + 1;
        sp.edit().putInt("k_count", n).putInt("k_mask", 0).putInt("k_last", 1).apply();
        new android.app.AlertDialog.Builder(a, Ui.pal(a).a ? 4 : 5)
                .setTitle(Ui.s("مبارك! 🎉", "Congratulations! 🎉"))
                .setMessage(Ui.s("أتممت ختمة القرآن الكريم، تقبّل الله منك. هذه ختمتك رقم ", "You have completed the whole Quran. May Allah accept it from you. Khatma number ") + Ui.n(n))
                .setPositiveButton(Ui.s("الحمد لله", "Alhamdulillah"), null)
                .show();
    }

    static void openJuz(final MainActivity a, final int juz, final Dialog parent, final LinearLayout parentBody) {
        final p1.c p = Ui.pal(a);
        final Dialog d = Ui.dialog(a);
        LinearLayout body = Ui.page(a, d, Ui.s("الجزء ", "Juz ") + Ui.n(juz));
        prefs(a).edit().putInt("k_last", juz).apply();

        int s = Quran.JUZ[juz - 1][0], v = Quran.JUZ[juz - 1][1];
        int es = juz < 30 ? Quran.JUZ[juz][0] : 115, ev = juz < 30 ? Quran.JUZ[juz][1] : 1;
        while (s < es || (s == es && v < ev)) {
            int last = s < es ? Quran.count(s) : ev - 1;
            if (v == 1) {
                body.addView(surahHeader(a, s), Ui.full(a, 14));
                if (s != 1 && s != 9) {
                    TextView b = quranText(a, basmala(), 22);
                    b.setGravity(Gravity.CENTER);
                    b.setTextColor(p.g);
                    body.addView(b, Ui.full(a, 10));
                }
            }
            addVerses(a, body, s, v, last, 24, 10);
            s++;
            v = 1;
        }

        final boolean isDone = (mask(a) & (1 << (juz - 1))) != 0;
        TextView mark = Ui.button(a, isDone ? Ui.s("هذا الجزء مقروء ✓", "This juz is read ✓")
                : Ui.s("أتممت قراءة الجزء ", "I finished Juz ") + Ui.n(juz) + " ✓", true);
        mark.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                int mm = mask(a) | (1 << (juz - 1));
                prefs(a).edit().putInt("k_mask", mm).putInt("k_last", juz % 30 + 1).apply();
                d.dismiss();
                if (doneCount(mm) == 30) completeKhatma(a);
                if (parent != null && parent.isShowing()) fillKhatma(a, parent, parentBody);
            }
        });
        body.addView(mark, Ui.full(a, 24));
        if (juz < 30) {
            TextView nx = Ui.button(a, Ui.s("الجزء التالي", "Next juz"), false);
            nx.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    d.dismiss();
                    openJuz(a, juz + 1, parent, parentBody);
                }
            });
            body.addView(nx, Ui.full(a, 8));
        }
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface di) {
                if (parent != null && parent.isShowing()) fillKhatma(a, parent, parentBody);
            }
        });
        d.show();
    }

    // ---------------------------------------------------------------- Ruqyah

    /** surah, from, to, repeat-note (0 = none, 3 = three times). */
    static final int[][] RUQYAH = {
        {1, 1, 7, 0}, {2, 1, 5, 0}, {2, 102, 102, 0}, {2, 163, 164, 0}, {2, 255, 257, 0}, {2, 284, 286, 0},
        {3, 18, 19, 0}, {7, 54, 56, 0}, {7, 117, 122, 0}, {10, 79, 82, 0}, {20, 65, 69, 0}, {23, 115, 118, 0},
        {37, 1, 10, 0}, {46, 29, 32, 0}, {59, 21, 24, 0}, {72, 1, 9, 0}, {112, 1, 4, 3}, {113, 1, 5, 3}, {114, 1, 6, 3},
    };

    /** Arabic text, source, repetition (Arabic), English meaning, repetition (English). */
    static final String[][] SUNNAH = {
        {"اللَّهُمَّ رَبَّ النَّاسِ، أَذْهِبِ الْبَأْسَ، اشْفِ أَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ، شِفَاءً لَا يُغَادِرُ سَقَمًا",
            "متفق عليه", "",
            "O Allah, Lord of mankind, remove the harm and heal, You are the Healer. There is no healing but Your healing, a healing that leaves no illness behind.",
            "Bukhari and Muslim", ""},
        {"بِسْمِ اللَّهِ أَرْقِيكَ، مِنْ كُلِّ شَيْءٍ يُؤْذِيكَ، مِنْ شَرِّ كُلِّ نَفْسٍ أَوْ عَيْنِ حَاسِدٍ، اللَّهُ يَشْفِيكَ، بِسْمِ اللَّهِ أَرْقِيكَ",
            "رواه مسلم", "",
            "In the name of Allah I perform ruqyah for you, from everything that harms you, from the evil of every soul or envious eye. May Allah heal you. In the name of Allah I perform ruqyah for you.",
            "Muslim", ""},
        {"بِسْمِ اللَّهِ، أَعُوذُ بِاللَّهِ وَقُدْرَتِهِ مِنْ شَرِّ مَا أَجِدُ وَأُحَاذِرُ",
            "رواه مسلم", "ضع يدك على موضع الألم وقل «بسم الله» ثلاثاً، ثم «أعوذ بالله وقدرته...» سبع مرات",
            "In the name of Allah. I seek refuge in Allah and His power from the evil of what I feel and fear.",
            "Muslim", "Put your hand on the place of pain, say “Bismillah” three times, then the rest seven times"},
        {"أَسْأَلُ اللَّهَ الْعَظِيمَ، رَبَّ الْعَرْشِ الْعَظِيمِ، أَنْ يَشْفِيَكَ",
            "رواه أبو داود والترمذي", "سبع مرات",
            "I ask Allah the Mighty, Lord of the Mighty Throne, to heal you.",
            "Abu Dawud and at-Tirmidhi", "Seven times"},
        {"أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّةِ، مِنْ كُلِّ شَيْطَانٍ وَهَامَّةٍ، وَمِنْ كُلِّ عَيْنٍ لَامَّةٍ",
            "رواه البخاري", "",
            "I seek refuge in the perfect words of Allah from every devil and poisonous creature, and from every evil eye.",
            "Bukhari", ""},
        {"أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
            "رواه مسلم", "ثلاث مرات",
            "I seek refuge in the perfect words of Allah from the evil of what He has created.",
            "Muslim", "Three times"},
        {"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
            "رواه أبو داود والترمذي", "ثلاث مرات",
            "In the name of Allah, with whose name nothing on earth or in heaven can cause harm, and He is the All-Hearing, the All-Knowing.",
            "Abu Dawud and at-Tirmidhi", "Three times"},
    };

    static void openRuqyah(final MainActivity a) {
        withQuran(a, new Then() {
            @Override public void run() {
                p1.c p = Ui.pal(a);
                Dialog d = Ui.dialog(a);
                LinearLayout body = Ui.page(a, d, Ui.s("الرقية الشرعية", "Ruqyah"));

                LinearLayout intro = Ui.card(a);
                intro.addView(Ui.text(a, Ui.s(
                        "الرقية الشرعية من القرآن الكريم والسنة النبوية. اقرأها على نفسك أو على المريض مع النفث، وأنت موقن أن الشفاء من الله وحده.",
                        "Ruqyah is healing recitation from the Quran and the Sunnah. Recite it over yourself or the sick person, blowing lightly, certain that healing comes from Allah alone."),
                        14, p.i, false));
                body.addView(intro, Ui.full(a, 6));

                body.addView(Ui.title(a, Ui.s("من القرآن الكريم", "From the Quran")), Ui.full(a, 18));
                for (int[] r : RUQYAH) {
                    LinearLayout c = Ui.card(a);
                    String range = r[1] == r[2] ? Ui.n(r[1]) : Ui.n(r[1]) + " – " + Ui.n(r[2]);
                    String head = (L10n.en() ? "Surah " + Quran.nameEn[r[0] - 1] : "سورة " + Quran.nameAr[r[0] - 1])
                            + (r[1] == 1 && r[2] == Quran.count(r[0]) ? "" : Ui.s(" (الآيات ", " (verses ") + range + ")");
                    c.addView(Ui.text(a, head, 14, p.g, true));
                    if (r[1] == 1 && r[0] != 1 && r[0] != 9) {
                        TextView b = quranText(a, basmala(), 21);
                        b.setGravity(Gravity.CENTER);
                        c.addView(b, Ui.full(a, 8));
                    }
                    addVerses(a, c, r[0], r[1], r[2], 22, 8);
                    if (r[3] == 3) c.addView(Ui.text(a, Ui.s("ثلاث مرات", "Three times"), 12, p.j, true), Ui.full(a, 6));
                    body.addView(c, Ui.full(a, 10));
                }

                body.addView(Ui.title(a, Ui.s("من السنة النبوية", "From the Sunnah")), Ui.full(a, 18));
                for (String[] s : SUNNAH) {
                    LinearLayout c = Ui.card(a);
                    TextView t = quranText(a, s[0], 19);
                    c.addView(t);
                    if (L10n.en()) c.addView(Ui.text(a, s[3], 14, p.i, false), Ui.full(a, 8));
                    String rep = L10n.en() ? s[5] : s[2];
                    if (rep.length() > 0) c.addView(Ui.text(a, rep, 12, p.j, true), Ui.full(a, 6));
                    c.addView(Ui.text(a, L10n.en() ? s[4] : s[1], 12, p.g, false), Ui.full(a, 6));
                    body.addView(c, Ui.full(a, 10));
                }
                d.show();
            }
        });
    }

    // ---------------------------------------------------------------- settings cards

    static boolean flipOn(Context c) {
        return prefs(c).getBoolean("flip", true);
    }

    /** Settings card: stop the Adhan and alerts by turning the phone face down. */
    public static final class FlipCard implements B1.l {
        private final MainActivity a;
        public FlipCard(MainActivity a) { this.a = a; }

        public static String title() { return Ui.s("قلب الجوال", "Flip to silence"); }

        @Override public Object h(Object o) {
            LinearLayout card = (LinearLayout) o;
            LinearLayout row = a.w(null, Ui.s("إيقاف الأذان والتنبيه عند قلب الجوال على وجهه", "Stop the Adhan and alerts when the phone is turned face down"),
                    flipOn(a), new B1.l() {
                        @Override public Object h(Object v) {
                            prefs(a).edit().putBoolean("flip", Boolean.TRUE.equals(v)).apply();
                            return q1.g.a;
                        }
                    });
            card.addView(row);
            card.addView(Ui.text(a, Ui.s("ضع الجوال على وجهه أثناء الأذان أو التنبيه ليتوقف الصوت فوراً.",
                    "Put the phone face down while the Adhan or an alert is sounding and it stops right away."), 12, Ui.pal(a).j, false), Ui.full(a, 4));
            return q1.g.a;
        }
    }

    /** Settings card: current version and the "Check for updates" button. */
    public static final class UpdateCard implements B1.l {
        private final MainActivity a;
        public UpdateCard(MainActivity a) { this.a = a; }

        public static String title() { return Ui.s("التحديثات", "Updates"); }

        @Override public Object h(Object o) {
            LinearLayout card = (LinearLayout) o;
            card.addView(Ui.text(a, Ui.s("الإصدار الحالي: ", "Current version: ") + Updater.versionName(a), 14, Ui.pal(a).i, false));
            TextView b = Ui.button(a, Ui.s("البحث عن تحديثات", "Check for updates"), true);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { Updater.check(a, true); }
            });
            card.addView(b, Ui.full(a, 10));
            return q1.g.a;
        }
    }

    /** Settings card: link to the privacy policy page. */
    public static final class PrivacyCard implements B1.l {
        private final MainActivity a;
        public PrivacyCard(MainActivity a) { this.a = a; }

        public static String title() { return Ui.s("سياسة الخصوصية", "Privacy Policy"); }

        @Override public Object h(Object o) {
            LinearLayout card = (LinearLayout) o;
            card.addView(Ui.text(a, Ui.s(
                    "كيف يتعامل التطبيق مع بياناتك، والأذونات المطلوبة.",
                    "How the app handles your data and the permissions it uses."),
                    14, Ui.pal(a).i, false));
            TextView b = Ui.button(a, Ui.s("عرض سياسة الخصوصية", "View Privacy Policy"), false);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        a.startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://claude.ai/artifact/KWhzEziSBaRZEGp7TRmkuB")));
                    } catch (ActivityNotFoundException ignored) {}
                }
            });
            card.addView(b, Ui.full(a, 10));
            return q1.g.a;
        }
    }

    /** Settings footer: app name, version and build date. */
    public static String footer(String ignored) {
        return Ui.s("نور المحراب • الإصدار ", "Noor Al-Mehrab • Version ") + BuildInfo.VERSION + " • " + Ui.s("بناء ", "Build ") + BuildInfo.BUILT;
    }
}
