package com.nooralmehrab.app;

/** Filled in by the build script. */
final class BuildInfo {
    private BuildInfo() {}

    static final String VERSION = "1.7.4";
    static final String BUILT = "2026-11-03 07:58";
    static final String UPDATE_URL = "https://raw.githubusercontent.com/al3m6i89-mind-ai/mind-ai/builds/noor-almehrab/update.json";
}
