package com.nooralmehrab.app;

import android.app.Dialog;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

final class PrivacySetup {
    private static final String KEY = "privacy_shown";

    static void check(MainActivity a) {
        if (Features.prefs(a).getBoolean(KEY, false)) return;
        Features.prefs(a).edit().putBoolean(KEY, true).apply();
        Dialog d = Ui.dialog(a);
        LinearLayout body = Ui.page(a, d, Ui.s("إفصاح عن الموقع", "Location Disclosure"));
        body.addView(Ui.text(a,
            Ui.s("يستخدم التطبيق موقعك الجغرافي لحساب أوقات الصلاة الدقيقة لمكانك.\n\n"
               + "يتم الحساب على جهازك مباشرةً ولا يُرسل موقعك إلى أي خادم خارجي.",
               "This app uses your location to calculate accurate prayer times.\n\n"
               + "Calculation happens on-device. Your location is never sent to any external server."),
            15, Ui.pal(a).i, false), Ui.full(a, 8));
        TextView btn = Ui.button(a, Ui.s("حسناً", "OK"), true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        body.addView(btn, Ui.full(a, 12));
        d.show();
    }
}
