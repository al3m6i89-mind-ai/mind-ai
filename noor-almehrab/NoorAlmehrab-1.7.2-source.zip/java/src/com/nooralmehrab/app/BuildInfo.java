package com.nooralmehrab.app;

/** Filled in by the build script. */
final class BuildInfo {
    private BuildInfo() {}

    static final String VERSION = "1.7.2";
    static final String BUILT = "2026-11-02 20:12";
    static final String UPDATE_URL = "";
}
